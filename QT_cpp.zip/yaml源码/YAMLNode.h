#pragma once
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

class YAMLNode
{
	friend class YAML;
private:
	bool inited;
	std::string name;						// the name of node
	std::vector<YAMLNode> childs;			// the child nodes
	std::string value;						// current value (un parsed)
	std::vector <std::string> toTok();

public:
	YAMLNode();
	YAMLNode(
		const std::string& name,
		const std::string& value,
		const std::vector<std::string>& tokens
	);	// parse from child string
	void parse(
		const std::string& name,				// self.name
		const std::string& value,				// self.value
		const std::vector<std::string>& tokens	// self.childs
	);

	template<typename T>
	T getValue();
	void setValue(int value);
	void setValue(long long int value);
	void setValue(double value);
	void setValue(std::string value);
	void setValue(const char* value);
	void setValue(bool value);
	void setRaw(const std::string& rawValue);
	bool isNull() const;
	const std::string& getRaw();
	const std::string& getName();
	std::string toString();

	YAMLNode(const YAMLNode&) = delete;
	YAMLNode& operator=(const YAMLNode&) = delete;
	YAMLNode(YAMLNode&& other) noexcept;
	YAMLNode& operator=(YAMLNode&& other) noexcept;
	YAMLNode& operator[](const std::string& key);
	YAMLNode& operator[](size_t index);
};

template<typename T>
inline T YAMLNode::getValue()
{
	if constexpr (std::is_same_v<T, int>) {
		try {
			int result = std::stoi(value, nullptr, 0);
			return result;
		}
		catch (const std::exception&) {
			throw std::runtime_error("Failed to convert value to int: " + value);
		}
	}
	else if constexpr (std::is_same_v<T, double>) {
		double result;
		std::istringstream iss(value);
		if (!(iss >> result)) {
			throw std::runtime_error("Failed to convert value to double: " + value);
		}
		return result;
	}
	else if constexpr (std::is_same_v<T, std::string>) {
		if (isNull()) {
			throw std::runtime_error("Failed to convert value to string: " + value);
		}

		size_t start = value.find_first_of('\"');
		size_t end = value.find_last_of('\"');
		if (start == std::string::npos || end == std::string::npos || end <= start) {
			throw std::runtime_error("Failed to convert value to string: " + value);
		}

		value[end] = '\0';
		std::string result = value.c_str() + start + 1;
		value[end] = '\"';
		return result;
	}
	else if constexpr (std::is_same_v<T, bool>) {
		size_t start = value.find_first_not_of(' ');
		size_t end = value.find_last_not_of(' ');
		value[end + 1] = '\0';
		std::string result = value.c_str() + start;
		value[end + 1] = ' ';

		if (result == "true" || result == "True") {
			return true;
		}
		else if (result == "false" || result == "False") {
			return false;
		}
		else {
			throw std::runtime_error("Failed to convert value to bool: " + value);
			return false;
		}
	}
	else {
		throw std::runtime_error("Invalid type: " + value);
		return T();
	}
}
