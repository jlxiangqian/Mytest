#pragma once
#include <string>
#include <vector>
#include "YAMLNode.h"

class YAML
{
public:
	YAML();
	YAML(const std::string& yamlString);
	void loadFromFile(const std::string& yamlFilePath);
	void loadFromString(const std::string& yamlString);
	void writeToFile(const std::string& yamlFilePath = "");
	void parse();				// parse the root
	YAMLNode& getRoot();
	std::string toString();

private:
	void preprocess(); // preprocess the yaml string

private:
	bool inited;
	std::string fileName;
	std::string filePath;
	std::string content;
	std::vector<std::string> tokens;
	YAMLNode root;
};
