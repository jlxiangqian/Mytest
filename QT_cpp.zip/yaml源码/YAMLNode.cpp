﻿#include "YAMLNode.h"
#include <iostream>

std::vector<std::string> YAMLNode::toTok()
{
	std::vector<std::string> toks;

	toks.emplace_back(name + std::string(": ") +
		(childs.empty() ?
			value : std::string(""))
	);

	for (size_t i = 0; i < childs.size(); i++) {
		std::vector<std::string> childTok = childs[i].toTok();
		for (std::string& tok : childTok) {
			toks.emplace_back("    " + tok);
		}
	}

	return toks;
}

YAMLNode::YAMLNode() : inited(false) {}

YAMLNode::YAMLNode(const std::string& name, const std::string& value, const std::vector<std::string>& tokens) : inited(false)
{
	parse(name, value, tokens);
}

void YAMLNode::parse(const std::string& name, const std::string& value, const std::vector<std::string>& tokens)
{
	this->inited = true;
	this->name = name;
	this->value = value;

	if (tokens.empty()) {
		return;			// if tokens are empty then return
	}

	const std::string& firstTok = tokens.front();
	size_t indentsCount = firstTok.find_first_not_of(' ');
	size_t currentIndentCount = -1;

	size_t lastChildTokIndex = 0;
	for (size_t i = 1; i < tokens.size(); i++) {
		const std::string& currentTok = tokens[i];
		currentIndentCount = currentTok.find_first_not_of(' ');

		if (currentIndentCount == indentsCount) { // if find the child token
			const std::string& lastTok = tokens[lastChildTokIndex];
			size_t separator = lastTok.find_first_of(':');
			if (separator == std::string::npos) {
				std::cerr << "Syntax error " << "line " << lastTok << std::endl;
			}

			size_t childNameStartIndex = lastTok.find_first_not_of(' ');
			std::string childName = lastTok.substr(childNameStartIndex, separator - childNameStartIndex);
			std::string childValue;
			if (separator == lastTok.length() - 1) {		// if no value
				childValue = "~";
			}
			else {
				childValue = lastTok.substr(
					separator + 1,
					lastTok.length() - separator - 1
				);

				size_t firstCharIndex = childValue.find_first_not_of(' ');
				childValue = (firstCharIndex == std::string::npos)
					? "~"
					: childValue.substr(firstCharIndex);
			}

			std::vector<std::string> toks(
				tokens.begin() + lastChildTokIndex + 1,
				tokens.begin() + i
			);
			childs.emplace_back(YAMLNode(
				std::move(childName),
				std::move(childValue),
				std::move(toks)
			));

			lastChildTokIndex = i;
		}
	}

	const std::string& lastTok = tokens[lastChildTokIndex];
	size_t separator = lastTok.find_first_of(':');
	if (separator == std::string::npos) {
		std::cerr << "Syntax error " << "line " << lastChildTokIndex << lastTok << std::endl;
	}

	size_t childNameStartIndex = lastTok.find_first_not_of(' ');
	std::string childName = lastTok.substr(childNameStartIndex, separator - childNameStartIndex);
	std::string childValue;
	if (separator == lastTok.length() - 1) {		// if no value
		childValue = "~";
	}
	else {
		childValue = lastTok.substr(
			separator + 1,
			lastTok.length() - separator - 1
		);

		size_t firstCharIndex = childValue.find_first_not_of(' ');
		childValue = (firstCharIndex == std::string::npos)
			? "~"
			: childValue.substr(firstCharIndex);
	}

	std::vector<std::string> toks(
		tokens.begin() + lastChildTokIndex + 1,
		tokens.end()
	);
	childs.emplace_back(YAMLNode(
		std::move(childName),
		std::move(childValue),
		std::move(toks)
	));
}

void YAMLNode::setValue(int value)
{
	this->value = std::to_string(value);;
}

void YAMLNode::setValue(long long int value)
{
	this->value = std::to_string(value);
}

void YAMLNode::setValue(double value)
{
	this->value = std::to_string(value);
}

void YAMLNode::setValue(std::string value)
{
	this->value = "\"" + value + "\"";
}

void YAMLNode::setValue(const char* value)
{
	std::string v = value;
	this->value = "\"" + v + "\"";
}

void YAMLNode::setValue(bool value)
{
	if (value == true) {
		this->value = "true";
	}
	else {
		this->value = "false";
	}
}

void YAMLNode::setRaw(const std::string& rawValue)
{
	value = rawValue;
}

bool YAMLNode::isNull() const
{
	return value == std::string("~");
}

const std::string& YAMLNode::getRaw()
{
	return value;
}

const std::string& YAMLNode::getName()
{
	return name;
}

std::string YAMLNode::toString()
{
	std::vector<std::string> toks = this->toTok();
	std::string yaml;
	yaml.reserve(500);
	for (const std::string& tok : toks) {
		yaml.operator+=(tok);
		yaml.push_back('\n');
	}

	return yaml;
}

YAMLNode::YAMLNode(YAMLNode&& other) noexcept
	: inited(other.inited),
	name(std::move(other.name)),
	childs(std::move(other.childs)),
	value(std::move(other.value))
{
	other.inited = this->inited;
}

YAMLNode& YAMLNode::operator=(YAMLNode&& other) noexcept {
	if (this != &other) {
		inited = other.inited;
		name = std::move(other.name);
		childs = std::move(other.childs);
		value = std::move(other.value);

		other.inited = this->inited;
	}
	return *this;
}

YAMLNode& YAMLNode::operator[](const std::string& key) {
	if (!inited) {
		throw std::runtime_error("the yaml root is not inited");
	}
	for (size_t i = 0; i < childs.size(); i++) {
		if (childs[i].name == key) {
			return childs[i];
		}
	}
	childs.push_back(YAMLNode(key, "~", std::vector<std::string>()));
	return childs.back();
}

YAMLNode& YAMLNode::operator[](size_t index) {
	if (!inited) {
		throw std::runtime_error("the yaml root is not inited");
	}
	if (index >= childs.size()) {
		throw std::out_of_range("YAMLNode index out of range");
	}
	return childs[index];
}
