﻿#include <filesystem>
#include <fstream>
#include "YAML.h"

YAML::YAML() : inited(false) {}

YAML::YAML(const std::string& yaml) : inited(false)
{
	if (std::filesystem::exists(yaml)) {
		loadFromFile(yaml);
	}
	else {
		loadFromString(yaml);
	}
}

void YAML::loadFromFile(const std::string& yamlFilePath)
{
	std::ifstream ifs(yamlFilePath, std::ios::in);
	if (!ifs) {
		throw std::runtime_error("Failed to open file: " + yamlFilePath);
	}

	ifs.seekg(0, std::ios::end);
	content.resize(ifs.tellg());
	ifs.seekg(0, std::ios::beg);

	ifs.read(&content[0], content.size());
	fileName = std::filesystem::path(yamlFilePath).filename().string();
	filePath = yamlFilePath;
}

void YAML::loadFromString(const std::string& yamlString)
{
	content = yamlString;
	fileName = "root";
}

void YAML::writeToFile(const std::string& yamlFilePath)
{
	if (yamlFilePath.empty() && filePath.empty()) {
		throw std::runtime_error("no file to write");
	}

	std::string writeFilePath = yamlFilePath.empty() ? filePath : yamlFilePath;
	std::string writeString = this->toString();

	std::filesystem::path p(writeFilePath);
	std::filesystem::path dir = p.parent_path();
	if (!dir.empty() && !std::filesystem::exists(dir)) {
		std::filesystem::create_directories(dir);
	}

	std::ofstream out(writeFilePath, std::ios::out | std::ios::trunc);
	if (!out.is_open()) {
		throw std::runtime_error("failed to open file for writing: " + writeFilePath);
	}

	out << writeString;

	if (!out.good()) {
		throw std::runtime_error("failed to write data to file: " + writeFilePath);
	}

	out.close();
}

void YAML::preprocess()
{
	char* content_ptr = content.data();
	std::vector<size_t> token_end_indexes;

	token_end_indexes.reserve(100);
	tokens.reserve(100);

	// process first line
	size_t first_char_index = content.find_first_not_of(' ');
	size_t first_return_index = content.find_first_of('\n');
	if (first_char_index < first_return_index) {
		if (content_ptr[first_char_index] != '#') {
			token_end_indexes.push_back(0);
		}
	}

	// process middle lines
	for (size_t i = 0; i < content.length(); i++) {
		if (content_ptr[i] == '#') {
			content_ptr[i] = '\0';
		}
		if (content_ptr[i] == '\n') {
			content_ptr[i] = '\0';
			token_end_indexes.push_back(i + 1);
		}
	}

	for (size_t i = 0; i < token_end_indexes.size(); i++) {
		std::string token(content_ptr + token_end_indexes[i]);
		if (!token.empty()) {
			tokens.push_back(std::move(token));
		}
	}
}

void YAML::parse()
{
	preprocess();
	root = YAMLNode(fileName, "~", tokens);
	inited = true;
}

YAMLNode& YAML::getRoot()
{
	if (!inited) {
		throw std::runtime_error("the yaml root is not inited");
	}
	return root;
}

std::string YAML::toString()
{
	std::string yaml;
	for (size_t i = 0; i < root.childs.size(); i++) {
		std::vector<std::string> childTok = root.childs[i].toTok();
		for (const std::string& tok : childTok) {
			yaml.operator+=(tok);
			yaml.push_back('\n');
		}
	}

	return yaml;
}
