﻿#include <chrono>
#include <filesystem>
#include "Config.h"
#include "Infer.h"
#include "Timer.h"
#include "VideoGet.h"
#include "VisionPipeline.h"
#include "AimController.h"
#include "cvsave.h"
#include "QBasic.h"

void VisionPipeline::init()
{
	destruct();
	cv::utils::logging::setLogLevel(cv::utils::logging::LOG_LEVEL_FATAL);

	if (!std::filesystem::exists(
		Config::instance().model_path
	)) {
		error_msg = "未找到模型";
	}

	try {
		VideoGet::instance(Config::instance().url).start();
		Infer::instance(Config::instance().model_path);
	}
	catch (const std::exception& e) {
		error_msg = e.what();
		printStackTrace();
	}
}

void VisionPipeline::start()
{
	stop();
	if (!error_msg.empty()) {
		return;
	}

	maxFps = Config::instance().max_fps;
	int interval = static_cast<int> (1000.0 / maxFps);
	tH = timer.schedule_interval(
		std::chrono::milliseconds(interval),
		&VisionPipeline::oneProcess
	);
	lastReportTime = (double)cv::getTickCount();

	working = true;
	checkThread = std::thread(&VisionPipeline::check);

	AimController::instance().start();
}

void VisionPipeline::stop()
{
	timer.cancel(tH);
	working = false;
	if (checkThread.joinable()) {
		checkThread.join();
	}

	fpsMonitorReset();

	AimController::instance().stop();
}

void VisionPipeline::fpsMonitorReset()
{
	_interval = 0;
	frameCount = 0;
	totalTimeMs = 0.0;
	lastReportTime = 0.0;
}

void VisionPipeline::destruct()
{
	stop();
	Infer::release();
	VideoGet::release();
	AimController::release();
}

void VisionPipeline::oneProcess()
{
	std::vector<Person> _people;
	try {
		current_frame = VideoGet::instance(Config::instance().url).get();
		_people = Infer::instance(Config::instance().model_path)(current_frame);
	}
	catch (const std::exception& e) {
		error_msg = e.what();
		printStackTrace();
	}

	_people = AimController::instance().processMove(_people);

	// ************
	//static CVSave cvSave;
	//cv::Mat frame_rgb = VideoGet::instance().get();

	//for (const auto& p : _people) {
	//	cv::rectangle(
	//		frame_rgb,
	//		cv::Rect(p.x, p.y, p.w, p.h),
	//		cv::Scalar(0, 255, 0),
	//		1
	//	);

	//	std::string id_text = std::to_string(p.id);

	//	cv::Point text_pos(p.x, p.y - 5);
	//	if (text_pos.y < 10) text_pos.y = p.y + 15;

	//	cv::putText(
	//		frame_rgb,
	//		id_text,
	//		text_pos,
	//		cv::FONT_HERSHEY_SIMPLEX,
	//		0.5,
	//		cv::Scalar(0, 0, 0),
	//		1,
	//		cv::LINE_AA
	//	);
	//}
	//if (GetAsyncKeyState(5) & 0x8000) {
	//	//cvSave.addMat(frame_rgb);
	//}
	//*************

   // refresh time
	int64_t thisTick = cv::getTickCount();
	double intervalMs = (thisTick - lastTK) * 1000.0 / cv::getTickFrequency();
	lastTK = thisTick;
	totalTimeMs += intervalMs;
	frameCount++;

	int64_t now = cv::getTickCount();
	double elapsedSec = (double)(now - lastReportTime) / cv::getTickFrequency();
	if (elapsedSec >= 1.0) {
		_interval = frameCount > 0 ? totalTimeMs / frameCount : 0.0;
		frameCount = 0;
		totalTimeMs = 0.0;
		lastReportTime = now;
	}

	{
		std::lock_guard lock(mtx);
		people = _people;
	}
}

void VisionPipeline::check()
{
	while (working) {
		for (int i = 0; i < 10; ++i) {
			if (!working) break;
			std::this_thread::sleep_for(std::chrono::milliseconds(100));
		}

		if (maxFps == Config::instance().max_fps) {
			continue;
		}

		maxFps = Config::instance().max_fps;
		int interval = static_cast<int>(1000.0 / maxFps);
		tH.get()->interval = std::chrono::milliseconds(interval);
		fpsMonitorReset();
	}
}

bool VisionPipeline::iferror()
{
	return error_msg.empty();
}

std::string VisionPipeline::handle_error()
{
	std::string result = error_msg;
	error_msg.clear();
	return result;
}

cv::Mat VisionPipeline::getCurrentFrame()
{
	std::lock_guard lock(mtx);
	return current_frame;
}

std::vector<Person> VisionPipeline::getCurrentPeople()
{
	std::lock_guard lock(mtx);
	return people;
}

std::array<std::array<int64_t, 4>, 2> VisionPipeline::getModelInfo()
{
	std::array<std::array<int64_t, 4>, 2> result = { 0 };
	try {
		result = Infer::instance(Config::instance().model_path).getModelInfo();
	}
	catch (const std::exception& e) {
		error_msg = e.what();
		printStackTrace();
	}

	return result;
}

double VisionPipeline::interval()
{
	return _interval;
}
