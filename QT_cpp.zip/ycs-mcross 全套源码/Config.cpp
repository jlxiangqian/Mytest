﻿#include <YAML.h>
#include <algorithm>
#include <fstream>
#include <qdebug>
#include <sstream>
#include <string>
#include "Config.h"
#include <iostream>
#include "QBasic.h"

int Config::loadConfig(const std::string& path)
{
	try
	{
		yaml = YAML(path);
		yaml.parse();
		YAMLNode& root = yaml.getRoot();

		// keys and aim
		vkey1 = root["KEY1"]["vkey"].getValue<int>();
		offset1 = root["KEY1"]["offset_y"].getValue<double>();

		vkey2 = root["KEY2"]["vkey"].getValue<int>();
		offset2 = root["KEY2"]["offset_y"].getValue<double>();
		dual_listen = root["DUAL_LISTEN"].getValue<bool>();
		auto_fire = root["AUTO_FIRE"].getValue<bool>();

		px = root["PID"]["PX"].getValue<double>();
		ix = root["PID"]["IX"].getValue<double>();
		dx = root["PID"]["DX"].getValue<double>();
		py = root["PID"]["PY"].getValue<double>();
		iy = root["PID"]["IY"].getValue<double>();
		dy = root["PID"]["DY"].getValue<double>();
		lead = root["PID"]["lead"].getValue<double>();


		// model and inference
		model_path = root["MODEL"]["model_path"].getValue<std::string>();
		class_id = root["MODEL"]["class_id"].getValue<int>();
		conf_threshold = root["MODEL"]["conf_threshold"].getValue<double>();
		iou_threshold = root["MODEL"]["iou_threshold"].getValue<double>();
		max_fps = root["MODEL"]["max_infer_fps"].getValue<int>();

		// hardware and connect
		mouse_input = root["HARDWARE"]["mouseInput"].getValue<std::string>();
		port = root["HARDWARE"]["port"].getValue<std::string>();

		// video frame
		url = root["VIDEO"]["url"].getValue<std::string>();
	/*	width = root["VIDEO"]["width"].getValue<int>();
		height = root["VIDEO"]["height"].getValue<int>();*/

		return 0;
	}
	catch (const std::exception& e)
	{
		std::cerr << "Config load failed: " << e.what() << std::endl;
		yaml = YAML();
		yaml.parse();
		return 1;
	}
}

void Config::writeConfig(const std::string& path)
{
	toYaml();

	std::filesystem::path pathObj(path);
	std::filesystem::path dir = pathObj.parent_path();

	if (!dir.empty() && !std::filesystem::exists(dir)) {
		std::filesystem::create_directories(dir);
	}

	std::ofstream ofs(path, std::ios::out | std::ios::trunc);
	ofs << "# YCS-MCROSS config file " << yaml.getRoot().getName() << std::endl;
	ofs << yaml.toString() << std::endl;
	ofs.close();
}

std::string Config::toString()
{
	toYaml();

	std::string result =
		"# YCS-MCROSS config file " +
		yaml.getRoot().getName() + "\n" +
		yaml.toString();

	return result;
}

void Config::toYaml()
{
	YAMLNode& root = yaml.getRoot();
	root["KEY1"]["vkey"].setValue(vkey1);
	root["KEY1"]["offset_y"].setValue(offset1);

	root["KEY2"]["vkey"].setValue(vkey2);
	root["KEY2"]["offset_y"].setValue(offset2);
	root["DUAL_LISTEN"].setValue(dual_listen);
	root["AUTO_FIRE"].setValue(auto_fire);

	root["PID"]["PX"].setValue(px);
	root["PID"]["IX"].setValue(ix);
	root["PID"]["DX"].setValue(dx);
	root["PID"]["PY"].setValue(py);
	root["PID"]["IY"].setValue(iy);
	root["PID"]["DY"].setValue(dy);
	root["PID"]["lead"].setValue(lead);

	root["MODEL"]["model_path"].setValue(model_path);
	root["MODEL"]["class_id"].setValue(class_id);
	root["MODEL"]["conf_threshold"].setValue(conf_threshold);
	root["MODEL"]["iou_threshold"].setValue(iou_threshold);
	root["MODEL"]["max_infer_fps"].setValue(max_fps);

	root["HARDWARE"]["mouseInput"].setValue(mouse_input);
	root["HARDWARE"]["port"].setValue(port);

	root["VIDEO"]["url"].setValue(url);
	/*root["VIDEO"]["width"].setValue(width);
	root["VIDEO"]["height"].setValue(height);*/
}

void Config::createConfig()
{
	// keys and aim
	vkey1 = 0;
	vkey2 = 0;
	offset1 = 0.0;
	offset2 = 0.0;
	dual_listen = false;
	auto_fire = false;

	px = 0.1;
	ix = 0.001;
	dx = 0.05;
	py = 0.1;
	iy = 0.001;
	dy = 0.05;
	lead = 10;

	// model and inference
	model_path = "";
	class_id = 0;
	conf_threshold = 0.5;
	iou_threshold = 0.5;
	max_fps = 200;

	// hardware and connect
	mouse_input = "WinAPI";
	port = "";
	ip = "";
	uuid = "";

	// video frame
	url = "udp://127.0.0.1:12345";
	/*width = 200;
	height = 200;*/
}

Config::Config()
{
	createConfig();
}
