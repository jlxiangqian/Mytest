﻿#include <QtWidgets/QApplication>
#include <Windows.h>
#include <qstylefactory.h>
#include "QBasic.h"
#include "SoftwareData.h"
#include "YCS.h"
#include "KBM.h"
#include "Config.h"

#ifdef _DEBUG
#pragma comment(lib, "yamld.lib")
#else
#pragma comment(lib, "yaml.lib")
#endif
#pragma comment(lib, "onnxruntime.lib")

#define WINDOW_NAME "QY转文字"
#define DEFAULT_NAME "YCS-MCROSS"

int main(int argc, char* argv[])
{
	//redirectCoutToVSOutput();
#ifndef _DEBUG
	redirectStdoutToFile("data/log");
#endif // _DEBUG
	SoftwareData::instance().init();

	QApplication app(argc, argv);
	app.setWindowIcon(QIcon(":/res/app_icon.ico"));

	YCS window;
	window.show();
	window.setWindowTitle(WINDOW_NAME);

	return app.exec();
}
