﻿//#include <dbghelp.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <qfileinfo.h>
#include <windows.h>
#include "QBasic.h"

// return the root widget of current widget.
QWidget* findRoot(QWidget* current) {
	QWidget* p = current;
	while (p->parentWidget()) {
		p = p->parentWidget();
	}

	return p;
}

// give a short display of long file path with no root dir
QString shortFilePath(const QString& fullPath)
{
	if (fullPath.isEmpty())
		return "";

	QString path = fullPath;
	path.replace('\\', '/');

	QFileInfo fileInfo(path);
	QString fileName = fileInfo.fileName();
	QString dir = fileInfo.absolutePath();

	QStringList dirParts = dir.split('/', Qt::SkipEmptyParts);

	QString result;
	if (!dirParts.isEmpty()) {
		result = dirParts.first() + "/.../" + fileName;
	}
	else {
		result = fileName;
	}

	return result;
}

// give a short display of long file path with root dir and parent dir
QString shortFilePath_dir(const QString& fullPath)
{
	if (fullPath.isEmpty())
		return "";

	QString path = fullPath;
	path.replace('\\', '/');

	QFileInfo fileInfo(path);
	QString fileName = fileInfo.fileName();
	QString dir = fileInfo.absolutePath();

	QStringList dirParts = dir.split('/', Qt::SkipEmptyParts);

	QString result;
	if (!dirParts.isEmpty()) {
		if (dirParts.size() <= 3) {
			result = dir + "/" + fileName;
		}
		else {
			QString firstDir = dirParts.first();
			QString secondDir = dirParts.at(1);
			QString lastDir = dirParts.last();
			result = firstDir + "/" + secondDir + "/.../" + lastDir + "/" + fileName;
		}
	}
	else {
		result = fileName;
	}

	return result;
}

bool inRange(double value, double left, double right)
{
	if (left >= right) {
		QString error_hint = QString("left should less than right left:%1 right:%2").arg(left).arg(right);
		throw std::runtime_error(error_hint.toStdString());
	}

	return (value >= left && value <= right);
}

bool inRange(int value, int left, int right)
{
	if (left >= right) {
		QString error_hint = QString("left should less than right left:%1 right:%2").arg(left).arg(right);
		throw std::runtime_error(error_hint.toStdString());
	}

	return (value >= left && value <= right);
}

std::string toWinString(QString str)
{
	return str.toLocal8Bit().constData();
}

QString fromWinString(const std::string& str)
{
	return QString::fromLocal8Bit(str.c_str());
}

std::wstring stringToWstring_utf8(const std::string& str) {
	int size_needed = MultiByteToWideChar(CP_UTF8, 0, str.c_str(),
		(int)str.size(), NULL, 0);
	std::wstring wstr(size_needed, 0);
	MultiByteToWideChar(CP_UTF8, 0, str.c_str(),
		(int)str.size(), &wstr[0], size_needed);
	return wstr;
}

std::wstring stringToWstring_2312(const std::string& str)
{
	if (str.empty()) return L"";
	int size_needed = MultiByteToWideChar(936, 0, str.c_str(), -1, nullptr, 0);
	std::wstring wstr(size_needed, 0);
	MultiByteToWideChar(936, 0, str.c_str(), -1, &wstr[0], size_needed);
	wstr.pop_back();
	return wstr;
}

std::string wstringToString_utf8(const std::wstring& wstr) {
	int size_needed = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(),
		(int)wstr.size(), NULL, 0, NULL, NULL);
	std::string str(size_needed, 0);
	WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(),
		(int)wstr.size(), &str[0], size_needed, NULL, NULL);
	return str;
}

std::string wstringToString_2312(const std::wstring& wstr) {
	int size_needed = WideCharToMultiByte(936, 0, wstr.c_str(),
		(int)wstr.size(), NULL, 0, NULL, NULL);
	std::string str(size_needed, 0);
	WideCharToMultiByte(936, 0, wstr.c_str(),
		(int)wstr.size(), &str[0], size_needed, NULL, NULL);
	return str;
}

//void printStackTrace()
//{
//	void* stack[64];
//	unsigned short frames;
//	SYMBOL_INFO* symbol;
//	HANDLE process = GetCurrentProcess();
//
//	SymInitialize(process, NULL, TRUE);
//	frames = CaptureStackBackTrace(0, 64, stack, NULL);
//
//	symbol = (SYMBOL_INFO*)calloc(sizeof(SYMBOL_INFO) + 256 * sizeof(char), 1);
//	symbol->MaxNameLen = 255;
//	symbol->SizeOfStruct = sizeof(SYMBOL_INFO);
//
//	std::cout << "Stack trace:\n";
//	for (unsigned short i = 0; i < frames; i++) {
//		SymFromAddr(process, (DWORD64)(stack[i]), 0, symbol);
//		std::cout << i << ": " << symbol->Name << " - 0x" << std::hex << symbol->Address << std::dec << "\n";
//	}
//
//	free(symbol);
//}

void printAllModule() {
	HANDLE hProcess = GetCurrentProcess();
	HMODULE hMods[1024];
	DWORD cbNeeded;

	if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
		unsigned int numModules = cbNeeded / sizeof(HMODULE);

		for (unsigned int i = 0; i < numModules; i++) {
			TCHAR szModName[MAX_PATH];

			if (GetModuleFileNameEx(hProcess, hMods[i], szModName, sizeof(szModName) / sizeof(TCHAR))) {
				std::wcout << L"[" << i << L"] " << szModName << std::endl;
			}
		}
	}
	else {
		std::cerr << "printAllModule failed: " << GetLastError() << std::endl;
	}
}

std::vector<uint8_t> loadFile(const std::string& fileName)
{
	std::ifstream file(fileName, std::ios::binary);
	if (!file) {
		return {};
	}

	file.seekg(0, std::ios::end);
	std::streamsize size = file.tellg();
	if (size <= 0) {
		return {};
	}

	std::vector<uint8_t> buffer(size);
	file.seekg(0, std::ios::beg);
	if (!file.read(reinterpret_cast<char*>(buffer.data()), size)) {
		return {};
	}

	return buffer;
}

int copyFile(const std::string& src, const std::string& dst)
{
	namespace fs = std::filesystem;

	try {
		if (!fs::exists(src)) {
			return 1;
		}

		std::ifstream test(src, std::ios::binary);
		if (!test.is_open()) {
			return 2;
		}
		test.close();

		fs::copy_file(src, dst, fs::copy_options::overwrite_existing);
		return 0;
	}
	catch (const fs::filesystem_error& e) {
		if (e.code() == std::errc::permission_denied) {
			return 2;
		}
		else if (e.code() == std::errc::no_such_file_or_directory) {
			return 1;
		}
		else {
			return 3;
		}
	}
	catch (...) {
		return 3;
	}
}

void redirectCoutToVSOutput() {
	static DebugStreamBuf debugStreamBuf;
	std::cout.rdbuf(&debugStreamBuf);
}

void redirectStdoutToFile(const std::string& log_dir)
{
	namespace fs = std::filesystem;

	if (!fs::exists(log_dir)) {
		fs::create_directories(log_dir);
	}

	auto now = std::chrono::system_clock::now();
	std::time_t t = std::chrono::system_clock::to_time_t(now);
	std::tm local_tm{};
	localtime_s(&local_tm, &t);

	std::ostringstream oss;
	oss << "log_"
		<< std::put_time(&local_tm, "%Y_%m_%d_%H_%M_%S")
		<< ".txt";

	fs::path log_path = fs::path(log_dir) / oss.str();

	static std::ofstream log_file(log_path.c_str());
	if (!log_file.is_open()) {
		std::cerr << "cannot open log file: " << log_path << std::endl;
		return;
	}

	std::cout.rdbuf(log_file.rdbuf());
	std::cerr.rdbuf(log_file.rdbuf());
}

std::string gb2312_to_utf16_bytes(const std::string& gb2312_str) {
	if (gb2312_str.empty()) return {};

	const UINT CP_GB2312 = 936;

	int wchar_count = MultiByteToWideChar(
		CP_GB2312, 0,
		gb2312_str.data(),
		static_cast<int>(gb2312_str.size()),
		nullptr, 0
	);
	if (wchar_count == 0)
		throw std::runtime_error("MultiByteToWideChar failed (get length)");

	std::wstring utf16_str(wchar_count, L'\0');

	int result = MultiByteToWideChar(
		CP_GB2312, 0,
		gb2312_str.data(),
		static_cast<int>(gb2312_str.size()),
		&utf16_str[0],
		wchar_count
	);
	if (result == 0)
		throw std::runtime_error("MultiByteToWideChar failed (convert)");

	std::string utf16_bytes(reinterpret_cast<const char*>(utf16_str.data()),
		utf16_str.size() * sizeof(wchar_t));

	return utf16_bytes;
}
