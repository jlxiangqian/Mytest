﻿#pragma once

#include <QDialog>
#include <qlabel.h>

class HintOverlay  : public QDialog
{
	Q_OBJECT

public:
	HintOverlay(QWidget *parent);
	void setHint(QString hint);
	void setHintSize(int fontSize);
	void setCloseCondition(std::function<bool()> cond);
	void showEvent(QShowEvent* event) override;
	void closeEvent(QCloseEvent* event) override;
	void keyPressEvent(QKeyEvent* event) override;
	~HintOverlay();

private slots:
	void checkCondition();

private:
	QLabel* label;
	QTimer* timer;
	std::function<bool()> closeCondition;
};

