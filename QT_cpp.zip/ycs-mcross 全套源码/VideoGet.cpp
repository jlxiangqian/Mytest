﻿#include "VideoGet.h"
#include "Config.h"
#include <windows.h>

cv::Mat VideoGet::get()
{
	std::lock_guard lock(mtx);
	return _current_frame;
}

void VideoGet::start()
{
	stop();
	working_checkthread = true;
	check_thread = std::thread(&VideoGet::check, this);
}

void VideoGet::stop()
{
	working_checkthread = false;
	if (check_thread.joinable()) {
		check_thread.join();
	}

	working_workthread = false;
	if (work_thread.joinable()) {
		work_thread.join();
	}
}

VideoGet::VideoGet() :
	working_checkthread(false),
	working_workthread(false),
	current_frame(cv::Size(640, 640), CV_8UC3, cv::Scalar(114, 114, 114)),
	_current_frame(cv::Size(640, 640), CV_8UC3, cv::Scalar(114, 114, 114))
{
}

VideoGet::VideoGet(const std::string& url) :
	working_checkthread(false),
	working_workthread(false),
	current_frame(cv::Size(640, 640), CV_8UC3, cv::Scalar(114, 114, 114)),
	_current_frame(cv::Size(640, 640), CV_8UC3, cv::Scalar(114, 114, 114))
{
	this->url = url;
}

VideoGet::~VideoGet()
{
	stop();
}

void VideoGet::work()
{
	std::vector<int> params = {
	  cv::CAP_PROP_OPEN_TIMEOUT_MSEC, 4500,
	  cv::CAP_PROP_READ_TIMEOUT_MSEC, 300
	};

	cap.open(url, cv::CAP_FFMPEG, params);

	if (!cap.isOpened()) {
		std::cerr << "cannot connet to video stream: " << url
			<< std::endl;
		_interval = 0;
		return;
	}

	// time calculate
	int frameCount = 0;
	double totalTimeMs = 0.0;
	double lastReportTime = (double)cv::getTickCount();

	while (working_workthread) {
		int64_t startTick = cv::getTickCount();

		bool rt = false;
		rt = cap.read(current_frame);
		if (!rt || current_frame.empty()) {
			std::cerr << "frame read failed!" << std::endl;
			{
				std::lock_guard lock(mtx);
				_current_frame = cv::Mat(
					cv::Size(640, 640),
					CV_8UC3,
					cv::Scalar(114, 114, 114)
				);
			}
			working_workthread = false;
			_interval = 0;
			break;
		}
		else {
			std::lock_guard lock(mtx);
			_current_frame = current_frame;
		}

		int64 endTick = cv::getTickCount();
		double frameTimeMs = (endTick - startTick) * 1000.0 / cv::getTickFrequency();

		totalTimeMs += frameTimeMs;
		frameCount++;

		double now = (double)cv::getTickCount();
		double elapsedSec = (now - lastReportTime) / cv::getTickFrequency();
		if (elapsedSec >= 1.0) {
			_interval = frameCount > 0 ? totalTimeMs / frameCount : 0.0;

			frameCount = 0;
			totalTimeMs = 0.0;
			lastReportTime = now;
		}
	}
	cap.release();
}

void VideoGet::check()
{
	while (working_checkthread) {
		for (int i = 0; i < 70; ++i) {
			if (!working_checkthread) break;
			std::this_thread::sleep_for(std::chrono::milliseconds(100));
		}

		if (Config::instance().url == url && cap.isOpened()) {
			continue;
		}

		url = Config::instance().url;
		start_work();
	}
}

void VideoGet::start_work()
{
	working_workthread = false;
	if (work_thread.joinable()) {
		work_thread.join();
	}

	working_workthread = true;
	work_thread = std::thread(&VideoGet::work, this);
}

double VideoGet::interval() const
{
	return _interval;
}

int VideoGet::getWidth() const
{
	return _current_frame.size().width;
}

int VideoGet::getHeight() const
{
	return _current_frame.size().height;
}
