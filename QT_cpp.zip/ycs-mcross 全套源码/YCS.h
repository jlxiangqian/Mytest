﻿#pragma once

#include <QtWidgets/QWidget>
#include "ui_YCS.h"
#include "ConfigurationEditor.h"
#include "DataDisplay.h"
#include "ControlPanel.h"

class YCS : public QWidget
{
	Q_OBJECT

public:
	YCS(QWidget* parent = nullptr);
	~YCS();

private:
	Ui::YCSClass ui;
	ConfigurationEditor* configurationEditor;
	DataDisplay* dataDisplay;
	ControlPanel* controlPanel;

private:
	void closeEvent(QCloseEvent* event) override;
	void onControlPanelMonitorPressed();
	void onControlPanelTestPressed();
};

