#pragma once

#include <QWidget>
#include "ui_ConfigurationEditor.h"

class ConfigurationEditor : public QWidget
{
	Q_OBJECT

public:
	ConfigurationEditor(QWidget *parent = nullptr);
	~ConfigurationEditor();

signals:
	void configChanged(); // when this emit, it will emit uiEdit and rawEdit

private:
	Ui::ConfigurationEditorClass ui;
	int lastIndex;
};
