﻿#pragma once
#include <opencv2/opencv.hpp>
#include <thread>

class VideoGet
{
public:
	static VideoGet& instance(const std::string& url = "") {
		if (!ins) {
			ins = new VideoGet(url);
		}
		return *ins;
	}
	static void release() {
		if (ins) {
			delete ins;
			ins = nullptr;
		}
	}

	cv::Mat get();
	void start();
	void stop();
	double interval() const;
	int getWidth() const;
	int getHeight() const;

private:
	static VideoGet* ins;
	VideoGet();
	VideoGet(const std::string& url);
	~VideoGet();
	void work();	// get frame from the stream
	void check();	// check whether the url is changed
	void start_work();	// restart work thread

	cv::Mat current_frame;
	cv::Mat _current_frame;

	std::string url;
	std::mutex mtx;
	std::thread work_thread;
	std::thread check_thread;

	cv::VideoCapture cap;

	std::atomic<bool> working_workthread;
	std::atomic<bool> working_checkthread;

	std::atomic<double> _interval;
};

inline VideoGet* VideoGet::ins = nullptr;
