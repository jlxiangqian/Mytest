﻿#pragma once
#include <chrono>
#include <cmath>
#include <deque>
#include <mutex>
#include <thread>
#include <vector>
#include "KalmanTracker.h"
#include "Infer.h"
#include "Timer.h"
#include "WinMouse.h"
#include "makcu.h"

class PIDController
{
private:
	double kp, ki, kd;
	double prevError = 0.0;
	double integral = 0.0;
	const double maxIntegral = 100.0;
	int stabilityCounter = 0;
	int stabilityThreshold = 5;
	double prevDerivative = 0.0;

public:
	PIDController(double kp = 0.4, double ki = 0.01, double kd = 0.05);
	void setPID(double kp, double ki, double kd);
	double operator()(double error);
	void clear();
};

class ByteTrack {
public:
	ByteTrack();
	ByteTrack(float iou_thres, float score_thres, int max_lost, int reset_thres);

	void setIOUThreshold(float val);
	void setScoreThreshold(float val);
	void setMaxLostTime(int val);
	void setResetThreshold(int val);

	void getPersonID(std::vector<Person>& people_without_id);
	void clear();

private:
	float calcIOU(const Person& a, const Person& b);

private:
	float iou_threshold;
	float score_threshold;
	int max_lost_time;
	int reset_threshold;
	int next_id;
	int no_target_frames;
	std::vector<Person> prev_people;
};

class AimController {
private:
	AimController();
	~AimController();
public:
	static AimController& instance() {
		if (!ins) {
			ins = new AimController();
		}

		return *ins;
	}

	static void release() {
		if (ins) {
			delete ins;
			ins = nullptr;
		}
	}

	std::vector<Person> processMove(const std::vector<Person>& _people);
	int findClosestIndex(const std::vector<Person>& _people) const;

	void start();
	void stop();
	void oneMove();
	void shoot();
	void check();

	box::MouseMakcu& getMakcu();
	WinMouse& getWinMouse();

private:
	void push(int dx);
	int isUseLead();

private:
	struct MoveInfo {
		int dx = 0;
		int dy = 0;
		bool valid = false;
	};

	static AimController* ins;
	int maxFps;
	std::string port;
	int centerX;
	int centerY;

	int aimID;
	int no_people_times_count;

	//ByteTrack byteTrack;
	KalmanTracker kalmanTracker;

	MoveInfo _move1;
	MoveInfo _move2;

	// PID
	PIDController pidx;
	PIDController pidy;

	std::mutex mtx;
	Timer timer;
	TaskHandle tH;
	std::thread check_thread;
	bool working = false;

	// mouse
	box::MouseMakcu makcu;
	WinMouse winMouse;

	std::deque<int> x_moves;

	// shoot
	std::chrono::steady_clock::time_point time_point;
	Person aimPerson;
};

inline AimController* AimController::ins = nullptr;
