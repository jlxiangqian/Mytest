﻿#pragma once

#include <QWidget>
#include "ui_ConfigurationEditorUI.h"

class ConfigurationEditorUI : public QWidget
{
	Q_OBJECT

public:
	ConfigurationEditorUI(QWidget *parent = nullptr);
	~ConfigurationEditorUI();

	// here will define the functions that bind with widget behaviours
signals:
	void configChanged();

private slots:
	void loadFromConfig(); // load ui from mem
	void onVkeyButton1Pressed();
	void onVkeyButton2Pressed();
	void onSetDualListenButtonPressed();
	void onSetAutoFireButtonPressed();
	void onOffsetSpinBox1Changed(double value);
	void onOffsetSpinBox2Changed(double value);
	// pid
	void onPXSpinBoxChanged(double value);
	void onIXSpinBoxChanged(double value);
	void onDXSpinBoxChanged(double value);
	void onPYSpinBoxChanged(double value);
	void onIYSpinBoxChanged(double value);
	void onDYSpinBoxChanged(double value);

	void onLeadSpinBoxChanged(double value);
	void onModelPathButtonPressed();
	void onAimClassIdChanged(int value);
	void onConfSpinBoxChanged(double value);
	void onIOUSpinBoxChanged(double value);
	void onModelInferMaxFPSChanged(int value);
	void onMouseInputComboBoxChanged(const QString& value);
	void onSerialSpinBoxChanged(int value);
	void onUrlLineEditChanged(const QString& value);
	void onFovSpinBoxChanged(int value);


private:
	Ui::ConfigurationEditorUIClass ui;
};

