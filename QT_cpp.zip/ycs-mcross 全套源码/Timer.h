#pragma once
#include <chrono>
#include <condition_variable>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <queue>
#include <thread>

struct Task {
	std::chrono::steady_clock::time_point nextTime;
	std::chrono::milliseconds interval;
	std::function<void()> func;
	bool canceled;

	Task(const std::chrono::steady_clock::time_point& time,
		const std::chrono::milliseconds& inter,
		const std::function<void()>& f)
		: nextTime(time), interval(inter), func(f), canceled(false) {
	}
};

typedef std::shared_ptr<Task> TaskHandle;
struct TaskCompare {
	bool operator()(const TaskHandle& a, const TaskHandle& b) const {
		return a->nextTime > b->nextTime;
	}
};

class TimeCost {
	std::chrono::steady_clock::time_point start;
	std::string name;
	bool ended;
public:
	TimeCost(std::string name = "") : name(name), ended(false) {
		start = std::chrono::steady_clock::now();
	}
	inline long long end() {
		if (ended) return -1;
		auto end = std::chrono::steady_clock::now();
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

		if (!name.empty())
			std::cout << name << " costs " << duration << " ms" << std::endl;

		ended = true;

		return duration;
	}
	~TimeCost() {
		if (ended) return;
		auto end = std::chrono::steady_clock::now();
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
		std::cout << name << " costs " << duration << " ms" << std::endl;
	}
};

class Timer {
public:
	Timer();
	~Timer();

	template<typename Func, typename... Args>
	TaskHandle schedule_interval(std::chrono::milliseconds interval, Func&& func, Args&&... args);

	template<typename Func, typename... Args>
	TaskHandle schedule_once(std::chrono::milliseconds delay, Func&& func, Args&&... args);

	void cancel(TaskHandle handle);

private:

	std::mutex mtx_;
	std::condition_variable cv_;
	std::priority_queue<TaskHandle, std::vector<TaskHandle>, TaskCompare> tasks_;
	std::thread worker_;
	bool stop_;

	void addTask(TaskHandle task);
	void run();
};

template<typename Func, typename ...Args>
TaskHandle Timer::schedule_interval(std::chrono::milliseconds interval, Func&& func, Args && ...args) {
	std::function<void()> taskFunc = std::bind(std::forward<Func>(func), std::forward<Args>(args)...);
	std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
	TaskHandle task = std::make_shared<Task>(now + interval, interval, taskFunc);
	addTask(task);
	return task;
}

template<typename Func, typename ...Args>
TaskHandle Timer::schedule_once(std::chrono::milliseconds delay, Func&& func, Args && ...args) {
	std::function<void()> taskFunc = std::bind(std::forward<Func>(func), std::forward<Args>(args)...);
	std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
	TaskHandle task = std::make_shared<Task>(now + delay, std::chrono::milliseconds(0), taskFunc);
	addTask(task);
	return task;
}
