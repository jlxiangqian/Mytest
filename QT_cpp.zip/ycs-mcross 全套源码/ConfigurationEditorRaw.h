#pragma once

#include <QWidget>
#include "ui_ConfigurationEditorRaw.h"

class ConfigurationEditorRaw : public QWidget
{
	Q_OBJECT

public:
	ConfigurationEditorRaw(QWidget* parent = nullptr);
	~ConfigurationEditorRaw();

signals:
	void configChanged();

private slots:
	void loadFromConfig();
	void onRawTextChanged();

private:
	Ui::ConfigurationEditorRawClass ui;
};
