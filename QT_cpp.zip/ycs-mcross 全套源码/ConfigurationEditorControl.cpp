﻿#include <iostream>
#include <qfiledialog.h>
#include <qmessagebox.h>
#include <string>
#include <windows.h>
#include "Config.h"
#include "ConfigurationEditorControl.h"
#include "QBasic.h"
#include "SoftwareData.h"

static int startEPSwitch(std::string epName)
{
	std::string relExePath = "eps/ep_switch.exe";
	std::string workDir = "";

	try {
		char modulePath[MAX_PATH];
		DWORD len = GetModuleFileNameA(NULL, modulePath, MAX_PATH);
		if (len == 0 || len == MAX_PATH) {
			return static_cast<int>(GetLastError());
		}

		std::filesystem::path fullPath(modulePath);
		std::filesystem::path exeFileName = fullPath.filename().string();
		std::filesystem::path exeDir = fullPath.parent_path();

		std::filesystem::path candidate = exeDir / relExePath;
		std::string fullExePath = candidate.lexically_normal().string();

		std::replace(fullExePath.begin(), fullExePath.end(), '/', '\\');

		std::string currentDirectory;
		if (workDir.empty()) {
			currentDirectory = exeDir.string();
			std::replace(currentDirectory.begin(), currentDirectory.end(), '/', '\\');
		}
		else {
			currentDirectory = workDir;
			std::replace(currentDirectory.begin(), currentDirectory.end(), '/', '\\');
		}

		std::string cmd = "\"" + fullExePath + "\"";

		if (!exeFileName.empty()) {
			cmd += " \"";
			std::string safeEp = exeFileName.string();
			std::replace(safeEp.begin(), safeEp.end(), '\"', '\'');
			cmd += safeEp;
			cmd += "\"";
		}

		if (!epName.empty()) {
			cmd += " \"";
			std::string safeEp = epName;
			std::replace(safeEp.begin(), safeEp.end(), '\"', '\'');
			cmd += safeEp;
			cmd += "\"";
		}

		std::vector<char> cmdBuf(cmd.begin(), cmd.end());
		cmdBuf.push_back('\0');

		STARTUPINFOA si;
		PROCESS_INFORMATION pi;
		ZeroMemory(&si, sizeof(si));
		ZeroMemory(&pi, sizeof(pi));
		si.cb = sizeof(si);

		DWORD creationFlags = CREATE_NEW_CONSOLE | CREATE_NEW_PROCESS_GROUP;

		std::cout << cmdBuf.data() << std::endl;
		std::cout << currentDirectory << std::endl;
		BOOL success = CreateProcessA(
			NULL,               // lpApplicationName: NULL -> 从 lpCommandLine 解析可执行模块
			cmdBuf.data(),      // lpCommandLine: 注意必须是可写缓冲区
			NULL,               // lpProcessAttributes
			NULL,               // lpThreadAttributes
			FALSE,              // bInheritHandles
			creationFlags,      // dwCreationFlags (detached)
			NULL,               // lpEnvironment
			currentDirectory.c_str(), // lpCurrentDirectory
			&si, &pi
		);

		if (!success) {
			return static_cast<int>(GetLastError());
		}

		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);

		return 0; // success
	}
	catch (const std::filesystem::filesystem_error& e) {
		// filesystem 相关错误
		(void)e;
		return ERROR_BAD_PATHNAME; // 或者你希望返回其他错误码
	}
}

ConfigurationEditorControl::ConfigurationEditorControl(QWidget* parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	connect(
		ui.importButton,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorControl::onImportButtonPressed
	);
	connect(
		ui.exportButton,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorControl::onExportButtonPressed
	);
	connect(
		ui.newConfigButton,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorControl::onNewConfigButtonPressed
	);
	connect(
		ui.switchEPButton,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorControl::onSwitchEPButtonPressed
	);
	connect(
		ui.autoSaveButton,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorControl::onAutoSaveButtonPressed
	);

	// config controll
	QString showText;
	if (std::filesystem::exists(SoftwareData::instance().getData()["lastConfigFile"].getValue<std::string>())) {
		showText = shortFilePath(
			fromWinString(
				SoftwareData::instance().getData()["lastConfigFile"].getValue<std::string>()
			)
		);
	}
	else {
		showText = "未选择配置文件";
	}
	ui.showCurrentConfigFilePath->setText(showText);

	// ep controll, autoSave
	std::string currentEP;
	bool autoSave;
	try {
		currentEP = SoftwareData::instance().
			getData()["currentEP"].getValue<std::string>();
		autoSave = SoftwareData::instance().
			getData()["autoSave"].getValue<bool>();
	}
	catch (const std::exception&) {
		currentEP = "dml";
		autoSave = true;
		SoftwareData::instance().getData()["currentEP"].setValue(currentEP);
		SoftwareData::instance().getData()["autoSave"].setValue(autoSave);
		SoftwareData::instance().write();
	}

	if (currentEP == "dml") {
		ui.dmlRatioButton->setChecked(true);
	}
	else if (currentEP == "cuda") {
		ui.cudaRatioButton->setChecked(true);
	}

	showText = QString("自动保存 = %1").arg(
		autoSave ? "true" : "false"
	);
	ui.showAutoSave->setText(showText);
}


ConfigurationEditorControl::~ConfigurationEditorControl()
{
}

void ConfigurationEditorControl::onImportButtonPressed()
{
	QString fileName = QFileDialog::getOpenFileName(
		this,
		"选择配置",
		"configs/",
		"配置文件 (*.yaml)"
	);

	if (!fileName.isEmpty()) {
		ui.showCurrentConfigFilePath->setText(shortFilePath(fileName));
		Config::instance().loadConfig(toWinString(fileName));

		YAMLNode& root = SoftwareData::instance().getData();
		std::string raw = std::format("\"{}\"", toWinString(fileName));
		root["lastConfigFile"].setRaw(raw);
		SoftwareData::instance().write();
	}
}

void ConfigurationEditorControl::onExportButtonPressed()
{
	QString fileName = QFileDialog::getSaveFileName(
		this,
		"导出配置",
		"configs/新配置.yaml",
		"配置文件 (*.yaml)"
	);

	if (!fileName.isEmpty()) {
		Config::instance().writeConfig(toWinString(fileName));
	}
}

void ConfigurationEditorControl::onNewConfigButtonPressed()
{
	Config::instance().createConfig();
	QString showText = "未选择配置文件";
	ui.showCurrentConfigFilePath->setText(showText);

	YAMLNode& root = SoftwareData::instance().getData();
	std::string raw = std::format("\"{}\"", toWinString("null"));
	root["lastConfigFile"].setRaw(raw);
	SoftwareData::instance().write();
}

void ConfigurationEditorControl::onSwitchEPButtonPressed()
{
	int ret = QMessageBox::question(
		this,
		"退出",
		"切换 EP 需要退出程序，是否退出？",
		QMessageBox::Yes | QMessageBox::No,
		QMessageBox::No
	);

	if (ret == QMessageBox::No) {
		return;
	}

	std::string currentEP;
	if (ui.dmlRatioButton->isChecked()) {		// use dml
		currentEP = "dml";
	}
	else if (ui.cudaRatioButton->isChecked()) { // use cuda
		currentEP = "cuda";
	}

	SoftwareData::instance().getData()["currentEP"].setValue(currentEP);
	SoftwareData::instance().write();

	startEPSwitch(currentEP);
}

void ConfigurationEditorControl::onAutoSaveButtonPressed()
{
	YAMLNode& root = SoftwareData::instance().getData();
	bool autoSave = root["autoSave"].getValue<bool>();

	QString showText = QString("自动保存 = %1").arg(
		!autoSave ? "true" : "false"
	);
	ui.showAutoSave->setText(showText);

	root["autoSave"].setValue(!autoSave);
	SoftwareData::instance().write();
}

