﻿#pragma once
#include <Windows.h>
#include <iostream>
#include <mutex>
#define FIT_LINE_LENGTH 50

namespace box
{
	class MouseMakcu
	{
	private:
		bool state = false; // true pressed, false released
		std::string serial = "";
		HANDLE serial_handle = nullptr;
		std::mutex mtx;
	public:
		MouseMakcu() = default;
		MouseMakcu(const std::string& _serial);
		~MouseMakcu();
		bool write(const std::string& command);
		std::string read();
		std::string writeAndRead(const std::string& _command);
		static MouseMakcu& getInstance();
		static MouseMakcu& getInstance(const std::string _serial);
		void setSerial(const std::string& _serial);
		void disConnet();
		void move(double x, double y);
		void leftDown();
		void leftUp();
		void pressAndReleaseKeyboardKey(int vkey);
		bool isConnect() const;
	};
}
