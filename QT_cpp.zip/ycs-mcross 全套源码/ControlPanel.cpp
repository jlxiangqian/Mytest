﻿#include <qmessagebox.h>
#include "ControlPanel.h"
#include "QBasic.h"
#include "VisionPipeline.h"

ControlPanel::ControlPanel(QWidget* parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	connect(
		ui.startButton,
		&QPushButton::pressed,
		this,
		&ControlPanel::onStartButtonPressed
	);
	VisionPipeline::init();
}

ControlPanel::~ControlPanel()
{
}

void ControlPanel::onStartButtonPressed()
{
	bool started = ui.startButton->isChecked();
	if (!started) {
		std::string error_msg = VisionPipeline::handle_error();
		if (error_msg.empty()) {
			VisionPipeline::start();
			ui.startButton->setText("停止");
		}
		else {
			QString msg = QString("出现错误：") + fromWinString(error_msg) + QString(" 请重试");
			QMessageBox::critical(
				nullptr,
				"错误",
				msg
			);
		}
	}
	else {
		VisionPipeline::stop();
		ui.startButton->setText("启动");
	}
}

QPushButton* ControlPanel::getStartButton() const
{
	return ui.startButton;
}

QPushButton* ControlPanel::getMonitorButton() const
{
	return ui.monitorButton;
}

QPushButton* ControlPanel::getTestButton() const
{
	return ui.testButton;
}
