﻿#include "ConfigurationEditorRaw.h"
#include "Config.h"
#include <iostream>
#include <QBasic.h>

ConfigurationEditorRaw::ConfigurationEditorRaw(QWidget* parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	loadFromConfig();
	connect(
		this,
		&ConfigurationEditorRaw::configChanged,
		this,
		&ConfigurationEditorRaw::loadFromConfig
	);
	connect(
		ui.setRawConfig,
		&QTextEdit::textChanged,
		this,
		&ConfigurationEditorRaw::onRawTextChanged
	);
}

ConfigurationEditorRaw::~ConfigurationEditorRaw()
{
}

void ConfigurationEditorRaw::onRawTextChanged()
{
	QString text = ui.setRawConfig->toPlainText();
	int result = Config::instance().loadConfig(toWinString(text));
	
	ui.showError->setText("配置已加载");
	if (result) {
		ui.showError->setText("存在错误*");
	}
}

void ConfigurationEditorRaw::loadFromConfig()
{
	QString config_string = fromWinString(Config::instance().toString());
	ui.setRawConfig->setText(config_string);
}
