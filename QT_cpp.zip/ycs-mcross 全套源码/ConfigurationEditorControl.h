﻿#pragma once

#include <QWidget>
#include "ui_ConfigurationEditorControl.h"

class ConfigurationEditorControl : public QWidget
{
	Q_OBJECT

public:
	ConfigurationEditorControl(QWidget *parent = nullptr);
	~ConfigurationEditorControl();

private slots:
	void onImportButtonPressed();
	void onExportButtonPressed();
	void onNewConfigButtonPressed();
	void onSwitchEPButtonPressed();
	void onAutoSaveButtonPressed();

private:
	Ui::ConfigurationEditorControlClass ui;
};
