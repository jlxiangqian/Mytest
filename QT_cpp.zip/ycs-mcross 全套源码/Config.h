﻿#pragma once
#include <qfile.h>
#include <qstring.h>
#include <YAML.h>

class Config
{
public:
	static Config& instance() {
		static Config config = Config();
		return config;
	}

	// keys and aim
	int vkey1 = 0, vkey2 = 0;
	double offset1 = 0, offset2 = 0;
	double px = 0, ix = 0, dx = 0;
	double py = 0, iy = 0, dy = 0;
	float lead = 0;
	bool dual_listen = false;
	bool auto_fire = false;

	// model and inference
	std::string model_path;
	int class_id = 0;
	double conf_threshold = 0, iou_threshold = 0;
	int max_fps;

	// hardware and connect
	std::string mouse_input;
	std::string port;
	std::string ip;
	std::string uuid;

	// video frame
	std::string url;
	int width = 0, height = 0;

	YAML yaml;
	int loadConfig(const std::string& path);			// load from disk or string
	void writeConfig(const std::string& path);			// write to disk
	std::string	toString();								// gen the yaml string
	void toYaml();										// apply change to yaml
	void createConfig();								// reset all params

private:
	std::string config_file_path;

private:
	Config();
	Config& operator=(const Config&) = delete;
};

