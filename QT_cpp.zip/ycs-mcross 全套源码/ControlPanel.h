﻿#pragma once

#include <QWidget>
#include "ui_ControlPanel.h"

class ControlPanel : public QWidget
{
	Q_OBJECT

public:
	ControlPanel(QWidget* parent = nullptr);
	~ControlPanel();

	QPushButton* getStartButton() const;
	QPushButton* getMonitorButton() const;
	QPushButton* getTestButton() const;

private:
	Ui::ControlPanelClass ui;
	void onStartButtonPressed();
};

