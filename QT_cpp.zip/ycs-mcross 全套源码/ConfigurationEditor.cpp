#include <QKeyEvent>
#include <iostream>
#include <qfiledialog.h>
#include "Config.h"
#include "ConfigurationEditor.h"
#include "ConfigurationEditorRaw.h"
#include "ConfigurationEditorUI.h"
#include "ConfigurationEditorControl.h"
#include "HintOverlay.h"
#include "QBasic.h"

ConfigurationEditor::ConfigurationEditor(QWidget* parent)
	: QWidget(parent), lastIndex(0)
{
	ui.setupUi(this);

	ConfigurationEditorUI* configurationEditorUI = new ConfigurationEditorUI();
	ConfigurationEditorRaw* configurationEditorRaw = new ConfigurationEditorRaw();
	ConfigurationEditorControl* configurationEditorControl = new ConfigurationEditorControl(ui.editControlTab);
	ui.uiEditTab->setWidget(configurationEditorUI);
	ui.rawEditTab->setWidget(configurationEditorRaw);
	
	connect(
		this,
		&ConfigurationEditor::configChanged,
		configurationEditorUI,
		&ConfigurationEditorUI::configChanged
	);
	connect(
		this,
		&ConfigurationEditor::configChanged,
		configurationEditorRaw,
		&ConfigurationEditorRaw::configChanged
	);

	connect(
		ui.tabWidget,
		&QTabWidget::currentChanged,
		this,
		[this](int index) {
			if (lastIndex <= 2) { // if last page is edit page
				emit configChanged();	// when mem config changed this will flash ui
			}
			lastIndex = index;
		}
	);
}

ConfigurationEditor::~ConfigurationEditor()
{
}
