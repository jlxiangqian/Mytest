#pragma once
#include <YAML.h>

class SoftwareData
{
public:
	static SoftwareData& instance() {
		static SoftwareData softwareData = SoftwareData();
		return softwareData;
	}

	void init();
	YAMLNode& getData();
	void write();


private:
	YAML yaml;
	SoftwareData() = default;
	SoftwareData& operator=(const SoftwareData&) = delete;
	
	void genConfig();
};
