#pragma once
#include <array>
#include <windows.h>
#include <vector>
#include <mutex>
#include <thread>
#include <atomic>
#include "AimController.h"

class KeyboardMonitor
{
public:
	KeyboardMonitor()
	{
		for (int i = 0; i < 256; ++i)
		{
			keysState[i] = false;
		}
	}
	KeyboardMonitor& operator=(KeyboardMonitor&& other) noexcept
	{
		if (this != &other)
		{
			if (isRunning)
			{
				isRunning = false;
				if (mThread.joinable())
					mThread.join();
			}

			this->isRunning = other.isRunning.exchange(false);
			this->mThread = std::move(other.mThread);
		}
		return *this;
	}
	~KeyboardMonitor()
	{
		if (isRunning)
		{
			isRunning = false;
			if (mThread.joinable())
			{
				mThread.join();
			}
		}
	}
	void startMonitor()
	{
		if (!isRunning)
		{
			isRunning = true;
			mThread = std::thread(&KeyboardMonitor::run, this);
		}
	}

	const bool operator [](int key) const
	{
		return keysState[key];
	}
private:
	std::atomic<bool> isRunning = false;
	std::array<std::atomic<bool>, 256> keysState;
	std::mutex mtx;
	std::thread mThread;
	void run()
	{
		while (isRunning)
		{
			for (int key = 0; key < 256; key++)
			{
				if (GetAsyncKeyState(key) & 0x8000) // Check if the key is pressed
				{

					keysState[key] = true;
				}
				else
				{
					keysState[key] = false;
				}
			}
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
	}
};

inline bool _GetKeyState(int vkey, bool dual = false) {

	bool state0 = GetAsyncKeyState(vkey) & 0x8000;
	bool state1 = false;
	if (dual && AimController::instance().getMakcu().isConnect()) {
		std::string result;
		switch (vkey)
		{
		case VK_LBUTTON: {
			result = AimController::instance()
				.getMakcu()
				.writeAndRead("km.left()");
			break;
		}
		case VK_RBUTTON: {
			result = AimController::instance()
				.getMakcu()
				.writeAndRead("km.right()");
			break;
		}
		case VK_MBUTTON: {
			result = AimController::instance()
				.getMakcu()
				.writeAndRead("km.middle()");
			break;
		}
		case VK_XBUTTON1: {
			result = AimController::instance()
				.getMakcu()
				.writeAndRead("km.side1()");
			break;
		}
		case VK_XBUTTON2: {
			result = AimController::instance()
				.getMakcu()
				.writeAndRead("km.side2()");
			break;
		}
		default:
			result = "";
			break;
		}

		if (!result.empty()) {
			size_t i = result.find_first_of('\n');
			if (i + 1 < result.length()) {
				state1 = result[i + 1] - 48;
			}
		}
	}
	//return state0 && state1;
	return state0 || state1;
}

