﻿#pragma once

class WinMouse
{
public:
	WinMouse();
	void move(double x, double y);
	void leftDown();
	void leftUp();
	void pressAndReleaseKeyboardKey(int vkey);
};
