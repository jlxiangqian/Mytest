﻿#pragma once
#include <Windows.h>
#include <qstring.h>
#include <qwidget.h>
#include <string>
#include <psapi.h>
#pragma comment(lib, "psapi.lib")
//#pragma comment(lib, "dbghelp.lib")

// return the root widget of current widget.
QWidget* findRoot(QWidget* current);

// give a short display of long file path with no root dir
QString shortFilePath(const QString& fullPath);

// give a short display of long file path with root dir and parent dir
QString shortFilePath_dir(const QString& fullPath);

// decide if the value is in the rfange of [left, right]
bool inRange(double value, double left, double right);
bool inRange(int value, int left, int right);

// call when need to save to file or memory
std::string toWinString(QString str);

// call when need to display
QString fromWinString(const std::string& str);

// convert std::string to std::wstring
std::wstring stringToWstring_utf8(const std::string& str);
std::wstring stringToWstring_2312(const std::string& str);

// convert std::wstring to std::string
std::string wstringToString_utf8(const std::wstring& wstr);
std::string wstringToString_2312(const std::wstring& wstr);

// call when catch error
inline void printStackTrace() {}

void printAllModule();

// load file
std::vector<uint8_t> loadFile(const std::string& fileName);

// 0: success, 1: not exists, 2: permission denied, 3: other reason
int copyFile(const std::string& src, const std::string& dst);

class DebugStreamBuf : public std::streambuf {
public:
	DebugStreamBuf() {
		setp(buffer, buffer + sizeof(buffer) - 1);
	}

protected:
	int_type overflow(int_type c) override {
		if (c != EOF) {
			*pptr() = static_cast<char>(c);
			pbump(1);
		}
		if (c == '\n' || pptr() >= epptr()) {
			flushBuffer();
		}
		return c;
	}

	int sync() override {
		flushBuffer();
		return 0;
	}

private:
	void flushBuffer() {
		int len = static_cast<int>(pptr() - pbase());
		if (len > 0) {
			std::string s(pbase(), len);
			OutputDebugStringA(s.c_str());
			pbump(-len); // reset buffer
		}
	}

	char buffer[512];
};

// redirect the output stream
void redirectCoutToVSOutput();

// redirect the output stream to file
void redirectStdoutToFile(const std::string& log_dir);

// gb2312 to utf16 bytes
std::string gb2312_to_utf16_bytes(const std::string& gb2312_str);