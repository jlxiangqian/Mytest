﻿#include <QBasic.h>
#include <algorithm>
#include <cpu_provider_factory.h>
#include <dml_provider_factory.h>
#include <onnxruntime_cxx_api.h>
#include "VisionPipeline.h"
#include "Config.h"
#include "Infer.h"

std::vector<Person> Infer::operator()(const cv::Mat& img)
{
	preprocess(img, processed_img, letterbox);
	imgToTensor(processed_img, input_tensor);
	inference(input_tensor, output_tensor);
	return postprocess(output_tensor, letterbox);
}

std::array<std::array<int64_t, 4>, 2> Infer::getModelInfo()
{
	return std::array<std::array<int64_t, 4>, 2> {
		input_shape,
		{ output_shape[0], output_shape[1], output_shape[2], 0 }
	};
}

Infer::Infer(std::string model_path) :
	env(ORT_LOGGING_LEVEL_ERROR, "YCS"),
	input_tensor(nullptr),
	output_tensor(nullptr),
	model_path(model_path)
{
	VisionPipeline::handle_error();
	std::vector<uint8_t> onnx_model = loadFile(model_path);
	if (onnx_model.empty()) {
		std::cout << "ONNX file is empty!" << std::endl;
		VisionPipeline::error_msg = "Model not choosed!";
		return;
	}

	try {
		Ort::SessionOptions options;

		auto providers = Ort::GetAvailableProviders();
		for (auto& p : providers) {
			if (p == "CUDAExecutionProvider") {
				OrtCUDAProviderOptions cuda_options;
				cuda_options.device_id = 0;
				cuda_options.arena_extend_strategy = 1;
				cuda_options.gpu_mem_limit = SIZE_MAX;
				cuda_options.cudnn_conv_algo_search = OrtCudnnConvAlgoSearchExhaustive;
				cuda_options.do_copy_in_default_stream = 1;

				options.AppendExecutionProvider_CUDA(cuda_options);
				std::cout << "Using CUDAExecutionProvider" << std::endl;
				break;
			}

			if (p == "DmlExecutionProvider") {
				Ort::ThrowOnError(OrtSessionOptionsAppendExecutionProvider_DML(options, 0));
				std::cout << "Using DmlExecutionProvider" << std::endl;
				break;
			}
		}

		options.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
		options.SetExecutionMode(ExecutionMode::ORT_PARALLEL);
		options.EnableMemPattern();
		options.EnableCpuMemArena();
		options.SetIntraOpNumThreads(std::thread::hardware_concurrency());
		options.SetInterOpNumThreads(1);

		session = Ort::Session(env, onnx_model.data(), onnx_model.size(), options);
	}
	catch (const std::exception& e) { // use cpu
		std::cerr << e.what() << std::endl;
		Ort::SessionOptions options;

		options.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
		options.SetIntraOpNumThreads(std::thread::hardware_concurrency());
		options.SetInterOpNumThreads(1);

		session = Ort::Session(env, onnx_model.data(), onnx_model.size(), options);
		std::cout << "Using CpuExecutionProvider" << std::endl;
	}

	memory_info = Ort::MemoryInfo::CreateCpu(
		OrtAllocatorType::OrtArenaAllocator,
		OrtMemType::OrtMemTypeDefault
	);
	PrintModelIOInfo();

	input_name = session.GetInputNameAllocated(0, allocator).get();
	output_name = session.GetOutputNameAllocated(0, allocator).get();

	Ort::TypeInfo type_info;
	Ort::ConstTensorTypeAndShapeInfo tensor_info;
	Ort::ShapeInferContext::Ints shape;
	ONNXTensorElementDataType input_type, output_type;

	type_info = session.GetInputTypeInfo(0);
	tensor_info = type_info.GetTensorTypeAndShapeInfo();
	shape = tensor_info.GetShape();
	input_type = tensor_info.GetElementType();
	for (size_t i = 0; i < shape.size() && i < input_shape.size(); i++) {
		input_shape[i] = shape[i];
	}

	type_info = session.GetOutputTypeInfo(0);
	tensor_info = type_info.GetTensorTypeAndShapeInfo();
	shape = tensor_info.GetShape();
	output_type = tensor_info.GetElementType();
	for (size_t i = 0; i < shape.size() && i < output_shape.size(); i++) {
		output_shape[i] = shape[i];
	}

	int TARGET_SIZE = input_shape[3];
	int RESOLUTION = output_shape[2];
	processed_img = cv::Mat(cv::Size(TARGET_SIZE, TARGET_SIZE), CV_8UC3, cv::Scalar(114, 114, 114));
	blob = cv::Mat(1, 3 * TARGET_SIZE * TARGET_SIZE, CV_32F, cv::Scalar(0));
	boxes.reserve(RESOLUTION);
	scores.reserve(RESOLUTION);
	indices.reserve(RESOLUTION);

	working_checkthread = true;
	check_thread = std::thread(&Infer::check, this);
}

Infer::~Infer()
{
	working_checkthread = false;
	if (check_thread.joinable()) {
		check_thread.join();
	}
}

void Infer::preprocess(const cv::Mat& img, cv::Mat& dist, Letterbox& letterbox)
{
	// reset background to gray
	dist.setTo(cv::Scalar(114, 114, 114));

	int height = img.rows;
	int width = img.cols;

	int big_edge = std::max(height, width);

	// 0 < scale_factor
	int64_t TARGET_SIZE = input_shape[3];
	double scale_factor = static_cast<double>(TARGET_SIZE) / big_edge;

	int new_h = static_cast<int>(scale_factor * height);
	int new_w = static_cast<int>(scale_factor * width);

	cv::Mat resized;
	cv::resize(
		img,
		resized,
		cv::Size((new_w), (new_h))
	);

	// center
	int top = static_cast<int>((TARGET_SIZE - new_h) / 2);
	int left = static_cast<int>((TARGET_SIZE - new_w) / 2);

	// copy to center
	resized.copyTo(dist(cv::Rect(left, top, new_w, new_h)));

	letterbox = {
		.pad_x = static_cast<float>(left),
		.pad_y = static_cast<float>(top),
		.scale = static_cast <float>(scale_factor),
	};
}

void Infer::imgToTensor(const cv::Mat& img, Ort::Value& input_tensor)
{
	int TARGET_SIZE = input_shape[3];

	cv::dnn::blobFromImage(
		img,
		blob,
		1.0 / 255.0,
		cv::Size(TARGET_SIZE, TARGET_SIZE),
		cv::Scalar(0, 0, 0),
		true,
		false
	);

	input_tensor = Ort::Value::CreateTensor<float>(
		memory_info,
		blob.ptr<float>(),
		blob.total(),
		input_shape.data(),
		input_shape.size()
	);
}

void Infer::inference(const Ort::Value& input_tensor, Ort::Value& output_tensor)
{
	std::array<const char*, 1>
		input_names = { input_name.c_str() },
		output_names = { output_name.c_str() };

	auto run_options = Ort::RunOptions();
	run_options.SetRunLogVerbosityLevel(0);
	run_options.AddConfigEntry("execution_mode", "parallel");
	run_options.AddConfigEntry("session.use_env_allocators", "1");
	run_options.AddConfigEntry("session.enable_mem_pattern", "1");

	session.Run(
		run_options,
		// input
		input_names.data(),
		&input_tensor,
		input_names.size(),

		// output
		output_names.data(),
		&output_tensor,
		output_names.size()
	);
}

std::vector<Person> Infer::postprocess(const Ort::Value& output_tensor, const Letterbox& letterbox)
{
	int C = static_cast<int>(output_shape[1]); // usually 56
	int N = static_cast<int>(output_shape[2]); // usually 8400

	if (N > C) {
		return postprocess_v8(output_tensor, letterbox);
	}
	else {
		return postprocess_v5(output_tensor, letterbox);
	}
}

std::vector<Person> Infer::postprocess_v8(const Ort::Value& output_tensor, const Letterbox& letterbox)
{
	boxes.clear();
	scores.clear();
	indices.clear();

	int C = static_cast<int>(output_shape[1]); // usually 56
	int N = static_cast<int>(output_shape[2]); // usually 8400

	const float* data = output_tensor.GetTensorData<float>();

	for (int j = 0; j < N; ++j)
	{
		const float cx = data[0 * N + j];
		const float cy = data[1 * N + j];
		const float w = data[2 * N + j];
		const float h = data[3 * N + j];
		const float score = data[(4 + Config::instance().class_id) * N + j];

		if (score < Config::instance().conf_threshold)
			continue;

		float x = cx - w * 0.5f;
		float y = cy - h * 0.5f;

		x = (x - letterbox.pad_x) / letterbox.scale;
		y = (y - letterbox.pad_y) / letterbox.scale;
		float box_w = w / letterbox.scale;
		float box_h = h / letterbox.scale;

		float real_cx = x + box_w * 0.5f;
		float real_cy = y + box_h * 0.5f;

		Person p;
		p.cx = real_cx;
		p.cy = real_cy;
		p.x = x;
		p.y = y;
		p.w = box_w;
		p.h = box_h;
		p.head_x = real_cx;
		p.head_y = y + 0.1 * box_h;
		p.score = score;

		boxes.emplace_back(cv::Rect(
			static_cast<int>(x),
			static_cast<int>(y),
			static_cast<int>(box_w),
			static_cast<int>(box_h)
		));
		scores.push_back(score);
	}

	cv::dnn::NMSBoxes(
		boxes, scores,
		Config::instance().conf_threshold,
		Config::instance().iou_threshold, indices
	);

	std::vector<Person> persons;
	persons.reserve(indices.size());
	for (int idx : indices)
	{
		persons.push_back(Person(
			boxes[idx].x + boxes[idx].width * 0.5f,
			boxes[idx].y + boxes[idx].height * 0.5f,
			static_cast<float>(boxes[idx].x),
			static_cast<float>(boxes[idx].y),
			static_cast<float>(boxes[idx].width),
			static_cast<float>(boxes[idx].height),
			boxes[idx].x + boxes[idx].width * 0.5f,
			static_cast<float>(boxes[idx].y),
			scores[idx]
		));
	}
	return persons;
}

std::vector<Person> Infer::postprocess_v5(const Ort::Value& output_tensor, const Letterbox& letterbox)
{
	boxes.clear();
	scores.clear();
	indices.clear();

	int N = static_cast<int>(output_shape[1]); // usually 8400
	int C = static_cast<int>(output_shape[2]); // usually 5

	const float* data = output_tensor.GetTensorData<float>();

	for (int j = 0; j < N; ++j)
	{
		const float cx = data[j * C + 0];
		const float cy = data[j * C + 1];
		const float w = data[j * C + 2];
		const float h = data[j * C + 3];
		const float score = data[j * C + Config::instance().class_id + 4];

		if (score < Config::instance().conf_threshold)
			continue;

		float x = cx - w * 0.5f;
		float y = cy - h * 0.5f;

		x = (x - letterbox.pad_x) / letterbox.scale;
		y = (y - letterbox.pad_y) / letterbox.scale;
		float box_w = w / letterbox.scale;
		float box_h = h / letterbox.scale;

		float real_cx = x + box_w * 0.5f;
		float real_cy = y + box_h * 0.5f;

		Person p;
		p.cx = real_cx;
		p.cy = real_cy;
		p.x = x;
		p.y = y;
		p.w = box_w;
		p.h = box_h;
		p.head_x = real_cx;
		p.head_y = y + 0.1f * box_h;
		p.score = score;

		boxes.emplace_back(cv::Rect(
			static_cast<int>(x),
			static_cast<int>(y),
			static_cast<int>(box_w),
			static_cast<int>(box_h)
		));
		scores.push_back(score);
	}

	cv::dnn::NMSBoxes(
		boxes, scores,
		Config::instance().conf_threshold,
		Config::instance().iou_threshold, indices
	);

	std::vector<Person> persons;
	persons.reserve(indices.size());
	for (int idx : indices)
	{
		persons.push_back(Person(
			boxes[idx].x + boxes[idx].width * 0.5f,
			boxes[idx].y + boxes[idx].height * 0.5f,
			static_cast<float>(boxes[idx].x),
			static_cast<float>(boxes[idx].y),
			static_cast<float>(boxes[idx].width),
			static_cast<float>(boxes[idx].height),
			boxes[idx].x + boxes[idx].width * 0.5f,
			static_cast<float>(boxes[idx].y),
			scores[idx]
		));
	}
	return persons;
}

void Infer::check()
{
	while (working_checkthread) {
		for (int i = 0; i < 50; ++i) {
			if (!working_checkthread) break;
			std::this_thread::sleep_for(std::chrono::milliseconds(100));
		}

		if (Config::instance().model_path == model_path) {
			continue;
		}

		working_checkthread = false;
	}
}

std::ostream& operator<<(std::ostream& os, const Person& p)
{
	os << "("
		<< p.cx << ", "
		<< p.cy << ", "
		<< p.w << ", "
		<< p.h << ")";
	return os;
}
