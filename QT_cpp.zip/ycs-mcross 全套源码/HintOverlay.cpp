﻿#include "HintOverlay.h"
#include <qlabel.h>
#include <QVBoxLayout>
#include <qtimer.h>
#include <QPropertyAnimation>
#include <qevent.h>

HintOverlay::HintOverlay(QWidget* parent)
	: QDialog(parent), label(nullptr), timer(nullptr)
{
	setWindowFlags(
		Qt::Dialog | Qt::CustomizeWindowHint
	);
	setModal(true);

	label = new QLabel("", this);
	label->setAlignment(Qt::AlignCenter);

	QVBoxLayout* layout = new QVBoxLayout(this);
	layout->addStretch();
	layout->addWidget(label);
	layout->addStretch();
	setLayout(layout);

	timer = new QTimer(this);
	connect(timer, &QTimer::timeout, this, &HintOverlay::checkCondition);
	timer->start(50);
}

void HintOverlay::setHint(QString hint)
{
	label->setText(hint);
}

void HintOverlay::setHintSize(int fontSize)
{
	QFont font = label->font();
	font.setPointSize(fontSize);
	label->setFont(font);
}

void HintOverlay::setCloseCondition(std::function<bool()> cond)
{
	closeCondition = cond;
}

void HintOverlay::checkCondition() {
	if (closeCondition && closeCondition()) {
		timer->stop();
		close();
	}
}

void HintOverlay::showEvent(QShowEvent* event) {
	QDialog::showEvent(event);

	QPropertyAnimation* anim = new QPropertyAnimation(this, "windowOpacity");
	anim->setDuration(500);
	anim->setStartValue(0);
	anim->setEndValue(1);
	anim->setEasingCurve(QEasingCurve::InOutCubic);
	anim->start(QAbstractAnimation::DeleteWhenStopped);
}

void HintOverlay::closeEvent(QCloseEvent* event) {
	QPropertyAnimation* anim = new QPropertyAnimation(this, "windowOpacity");
	anim->setDuration(500);
	anim->setStartValue(1);
	anim->setEndValue(0);
	connect(anim, &QPropertyAnimation::finished, this, &QDialog::accept);
	anim->setEasingCurve(QEasingCurve::InOutCubic);
	anim->start(QAbstractAnimation::DeleteWhenStopped);

	event->ignore();
}

inline void HintOverlay::keyPressEvent(QKeyEvent* event)
{
	if (event->key() == Qt::Key_Escape)
		event->ignore();
	else
		QDialog::keyPressEvent(event);
}

HintOverlay::~HintOverlay()
{
}

