﻿#pragma once
#include <deque>
#include <opencv2/opencv.hpp>
#include <thread>
#include <format>

class CVSave
{
public:
	CVSave();
	~CVSave();
	void addMat(const cv::Mat mat);

private:
	std::deque<cv::Mat> tasks;
	size_t count;
	std::mutex mtx;
	std::thread workThread;
	std::atomic<bool> working;

	void work();
};

CVSave::CVSave() :count(0)
{
	working = true;
	workThread = std::thread(&CVSave::work, this);
}

CVSave::~CVSave()
{
	working = false;
	if (workThread.joinable()) {
		workThread.join();
	}
}

inline void CVSave::addMat(const cv::Mat mat)
{
	std::lock_guard lock(mtx);
	tasks.push_back(mat);
}

inline void CVSave::work()
{
	while (working) {
		while (!tasks.empty()) {
			cv::Mat t;
			{
				std::lock_guard lock(mtx);
				t = tasks.front();
			}
			tasks.pop_front();

			std::string fileName = std::format("test_dir/{}.jpg", count++);
			cv::imwrite(fileName, t);
		}
	}
}
