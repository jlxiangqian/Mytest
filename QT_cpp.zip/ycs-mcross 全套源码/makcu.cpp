﻿// Makcu.cpp : 定义静态库的函数。
//
#include "makcu.h"

box::MouseMakcu::MouseMakcu(const std::string& _serial) {
	this->setSerial(_serial);
}

box::MouseMakcu::~MouseMakcu()
{
	disConnet();
}

bool box::MouseMakcu::write(const std::string& command) {
	DWORD written;
	bool result;
	{
		std::string command_r = command + "\r";
		std::lock_guard<std::mutex> lock(mtx);
		result = WriteFile(
			serial_handle,
			command_r.c_str(),
			static_cast<DWORD> (command_r.length()),
			&written, nullptr
		);
	}

	if (!result) {
		DWORD err = GetLastError();
		std::cerr << "WriteFile failed, error code " << err << std::endl;
		return false;
	}
	else {
		if (written != (command.length() + 1)) {
			std::cerr << "WriteFile not completed!" << std::endl;
			return false;
		}
	}

	return true;
}

std::string box::MouseMakcu::read()
{
	std::string out;
	char ch = 0;
	DWORD bytesRead;

	while (true) {
		if (!ReadFile(serial_handle, &ch, 1, &bytesRead, NULL)) {
			std::cerr << "ReadFile failed: " << GetLastError() << std::endl;
			return "ERROR";
		}

		if (bytesRead == 0) {
			break;
		}

		if (ch == '\r') {
			break;
		}

		out.push_back(ch);
	}

	return out;
}

std::string box::MouseMakcu::writeAndRead(const std::string& command)
{
	PurgeComm(serial_handle, PURGE_RXCLEAR | PURGE_TXCLEAR);
	auto result = this->write(command);
	if (!result) {
		return "ERROR";
	}

	return this->read();
}

box::MouseMakcu& box::MouseMakcu::getInstance() {
	static MouseMakcu mouseMakcu;
	return mouseMakcu;
}

box::MouseMakcu& box::MouseMakcu::getInstance(const std::string _serial) {
	MouseMakcu::getInstance().setSerial(_serial);
	return MouseMakcu::getInstance();
}

void box::MouseMakcu::setSerial(const std::string& _serial) {
	serial = _serial;

	if (serial_handle != INVALID_HANDLE_VALUE && serial_handle != nullptr) {
		CloseHandle(serial_handle);
		serial_handle = INVALID_HANDLE_VALUE;
	}

	char com_temp[20];
	if (serial.length() >= 10) {
		std::cerr << "Serial is illegle." << std::endl;
	}

	sprintf_s(com_temp, sizeof(com_temp), "\\\\.\\%s", serial.c_str());

	serial_handle = CreateFileA(com_temp,
		GENERIC_READ | GENERIC_WRITE,
		0, nullptr,
		OPEN_EXISTING,
		0, nullptr);

	if (serial_handle == INVALID_HANDLE_VALUE) {
		std::cerr << "cannot open " << com_temp << " " << GetLastError() << std::endl;
		return;
	}

	DCB dcb = { 0 };
	dcb.DCBlength = sizeof(dcb);
	GetCommState(serial_handle, &dcb);
	dcb.BaudRate = CBR_115200;
	dcb.ByteSize = 8;
	dcb.StopBits = ONESTOPBIT;
	dcb.Parity = NOPARITY;
	SetCommState(serial_handle, &dcb);

	COMMTIMEOUTS timeouts = { 0 };
	timeouts.ReadIntervalTimeout = MAXDWORD;
	timeouts.ReadTotalTimeoutConstant = 100;
	timeouts.ReadTotalTimeoutMultiplier = 0;
	SetCommTimeouts(serial_handle, &timeouts);
}

void box::MouseMakcu::disConnet()
{
	serial = "";
	CloseHandle(serial_handle);
	serial_handle = nullptr;
}

void box::MouseMakcu::move(double x, double y) {
	char command[50];
	double distance = sqrt(x * x + y * y);
	sprintf_s(
		command,
		sizeof(command),
		"km.move(%d,%d,%d)",
		static_cast<int>(x),
		static_cast<int>(y),
		static_cast<int>(distance / FIT_LINE_LENGTH)
	);
	this->write(command);
}

void box::MouseMakcu::leftDown() {
	this->write("km.left(1)");
}

void box::MouseMakcu::leftUp() {
	this->write("km.left(0)");
}

void box::MouseMakcu::pressAndReleaseKeyboardKey(int vkey) {}

bool box::MouseMakcu::isConnect() const {
	return (serial_handle != INVALID_HANDLE_VALUE);
}
