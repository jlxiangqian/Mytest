﻿#pragma once
#pragma once
#include <vector>
#include <opencv2/opencv.hpp>
#include <algorithm>
#include "Infer.h"
#include <limits>
#include <mutex>


class KalmanTracker {
public:
    // ========== 构造 ==========
    KalmanTracker()
        : processNoise(1e-2f),
        measurementNoise(1e-1f),
        distThreshold(50.0f),
        maxLost(30),
        resetThreshold(60),
        nextId(0),
        noTargetFrames(0)
    {
    }

    KalmanTracker(float procNoise, float measNoise, float distThresh, int max_lost, int reset_thresh)
        : processNoise(procNoise),
        measurementNoise(measNoise),
        distThreshold(distThresh),
        maxLost(max_lost),
        resetThreshold(reset_thresh),
        nextId(0),
        noTargetFrames(0)
    {
    }

    // ========== 参数热更新接口 ==========
    void setProcessNoise(float v) { std::lock_guard<std::mutex> lk(mtx); processNoise = v; updateAllKFNoise(); }
    void setMeasurementNoise(float v) { std::lock_guard<std::mutex> lk(mtx); measurementNoise = v; updateAllKFNoise(); }
    void setDistThreshold(float v) { std::lock_guard<std::mutex> lk(mtx); distThreshold = v; }
    void setMaxLost(int v) { std::lock_guard<std::mutex> lk(mtx); maxLost = v; }
    void setResetThreshold(int v) { std::lock_guard<std::mutex> lk(mtx); resetThreshold = v; }

    // ========== 主函数：为每个 Person 分配 id 并保存状态 ==========
    void getPersonID(std::vector<Person>& people_without_id) {
        std::lock_guard<std::mutex> lk(mtx);

        // 如果当前帧没有检测到目标
        if (people_without_id.empty()) {
            ++noTargetFrames;
            // 增加丢失计数，清理超时轨迹
            for (auto it = tracks.begin(); it != tracks.end(); ) {
                it->lost += 1;
                if (it->lost > maxLost) it = tracks.erase(it);
                else ++it;
            }
            if (noTargetFrames >= resetThreshold) {
                clear();
            }
            // 保持 prev_people 不变（或可置空），这里保持不变
            return;
        }

        // 有目标，重置无人帧计数
        noTargetFrames = 0;

        // 1) 先对每个 track 做预测（得到预测中心）
        for (auto& t : tracks) {
            cv::Mat pred = t.kf.predict(); // state: [cx, cy, vx, vy]^T
            t.pred_cx = static_cast<float>(pred.at<float>(0));
            t.pred_cy = static_cast<float>(pred.at<float>(1));
        }

        // 2) 准备检测中心数组
        struct DetInfo { int idx; float cx, cy; float score; };
        std::vector<DetInfo> dets;
        dets.reserve(people_without_id.size());
        for (size_t i = 0; i < people_without_id.size(); ++i) {
            Person& p = people_without_id[i];
            // 如果检测置信度极低，也可以选择直接过滤；这里不强制过滤，保留上层决定
            dets.push_back({ (int)i, p.cx, p.cy, p.score });
        }

        // 3) 构建所有 track - det 距离对，贪心匹配（按距离从小到大）
        struct Match { int trackIdx; int detIdx; float dist; };
        std::vector<Match> matches;
        matches.reserve(tracks.size() * dets.size());
        for (size_t ti = 0; ti < tracks.size(); ++ti) {
            for (size_t di = 0; di < dets.size(); ++di) {
                float dx = tracks[ti].pred_cx - dets[di].cx;
                float dy = tracks[ti].pred_cy - dets[di].cy;
                float d = std::sqrt(dx * dx + dy * dy);
                if (d <= distThreshold) {
                    matches.push_back({ (int)ti, (int)di, d });
                }
            }
        }
        // 按距离升序
        std::sort(matches.begin(), matches.end(), [](const Match& a, const Match& b) { return a.dist < b.dist; });

        // 4) 贪心分配：每 track 只会被分配一次，每 det 只会分配一次
        std::vector<int> trackAssigned(tracks.size(), -1);
        std::vector<int> detAssigned(dets.size(), -1);
        for (const auto& m : matches) {
            if (trackAssigned[m.trackIdx] != -1) continue;
            if (detAssigned[m.detIdx] != -1) continue;
            trackAssigned[m.trackIdx] = m.detIdx;
            detAssigned[m.detIdx] = m.trackIdx;
        }

        // 5) 更新已匹配轨迹
        for (size_t ti = 0; ti < tracks.size(); ++ti) {
            int di = trackAssigned[ti];
            if (di != -1) {
                // 有匹配，修正卡尔曼
                DetInfo& d = dets[di];
                cv::Mat measurement(2, 1, CV_32F);
                measurement.at<float>(0) = d.cx;
                measurement.at<float>(1) = d.cy;

                // === 平滑修改开始 ===
                // 先预测
                cv::Mat pred = tracks[ti].kf.predict();
                float pred_cx = pred.at<float>(0);
                float pred_cy = pred.at<float>(1);

                // 再修正
                cv::Mat corr = tracks[ti].kf.correct(measurement);
                float smooth_cx = corr.at<float>(0);
                float smooth_cy = corr.at<float>(1);

                // 写回人物（平滑位置）
                Person& p = people_without_id[d.idx];
                float alpha = 0.7f; // 平滑强度：越接近1越平滑，越小响应越快
                p.cx = alpha * smooth_cx + (1 - alpha) * p.cx;
                p.cy = alpha * smooth_cy + (1 - alpha) * p.cy;
                // 如果需要，可以保持 w,h 不变或稍微平滑：
                // p.w = 0.8f * p.w + 0.2f * tracks[ti].last.w;
                // p.h = 0.8f * p.h + 0.2f * tracks[ti].last.h;
                // === 平滑修改结束 ===

                // 更新轨迹状态
                tracks[ti].lost = 0;
                tracks[ti].age += 1;
                tracks[ti].pred_cx = smooth_cx;
                tracks[ti].pred_cy = smooth_cy;
                tracks[ti].last = p;

                // 写入ID
                people_without_id[d.idx].id = tracks[ti].id;
            }
            else {
                // 未匹配，增加丢失计数
                tracks[ti].lost += 1;

                // === 平滑修改：用预测更新轨迹中心 ===
                cv::Mat pred = tracks[ti].kf.predict();
                tracks[ti].pred_cx = pred.at<float>(0);
                tracks[ti].pred_cy = pred.at<float>(1);
                // === 结束 ===
            }
        }

        // 6) 为未匹配的检测创建新轨迹
        for (size_t di = 0; di < dets.size(); ++di) {
            if (detAssigned[di] == -1) {
                // create new track
                Person& p = people_without_id[dets[di].idx];
                Track newt;
                initKalman(newt.kf, p.cx, p.cy);
                newt.id = nextId++;
                newt.lost = 0;
                newt.age = 1;
                newt.last = p;
                newt.pred_cx = p.cx;
                newt.pred_cy = p.cy;
                tracks.push_back(std::move(newt));
                // assign id
                people_without_id[dets[di].idx].id = nextId - 1;
                detAssigned[di] = (int)(tracks.size() - 1); // not necessary
            }
        }

        // 7) 清除超时轨迹
        for (auto it = tracks.begin(); it != tracks.end(); ) {
            if (it->lost > maxLost) it = tracks.erase(it);
            else ++it;
        }

        // 8) 保存当前帧状态到 prev_people（拷贝）
        prev_people.clear();
        prev_people.reserve(people_without_id.size());
        for (const auto& p : people_without_id) prev_people.push_back(p);
    }

    // ========== 清空状态 ==========
    void clear() {
        tracks.clear();
        prev_people.clear();
        nextId = 0;
        noTargetFrames = 0;
    }

    // ========== 获取上一次保存的 people ==========
    std::vector<Person> getPrevPeople() const {
        std::lock_guard<std::mutex> lk(mtx);
        return prev_people;
    }

private:
    // ====== 单个轨迹结构 ======
    struct Track {
        cv::KalmanFilter kf; // state: cx,cy,vx,vy
        int id = -1;
        int lost = 0; // 丢失帧计数
        int age = 0;  // 存活帧计数
        Person last;  // 上次关联的检测
        float pred_cx = 0.0f;
        float pred_cy = 0.0f;

        Track() : kf(4, 2, 0, CV_32F) {}
    };

    // ====== 成员参数（可热更新） ======
    float processNoise;      // 过程噪声（越大响应越灵敏但更噪）
    float measurementNoise;  // 观测噪声（越大更信任预测）
    float distThreshold;     // 匹配阈值（像素距离）
    int maxLost;             // 最大丢失帧数（超过则删除轨迹）
    int resetThreshold;      // 连续无人多少帧后整体清零

    // ====== 状态 ======
    std::vector<Track> tracks;
    std::vector<Person> prev_people;
    int nextId;
    int noTargetFrames;

    mutable std::mutex mtx;

    // ====== 初始化卡尔曼滤波器（cx,cy 初值） ======
    void initKalman(cv::KalmanFilter& kf, float cx, float cy) {
        kf = cv::KalmanFilter(4, 2, 0, CV_32F);
        // State: [cx, cy, vx, vy]^T
        // Measurement: [cx, cy]^T

        // Transition matrix A
        // [1 0 1 0]
        // [0 1 0 1]
        // [0 0 1 0]
        // [0 0 0 1]
        kf.transitionMatrix = (cv::Mat_<float>(4, 4) <<
            1, 0, 1, 0,
            0, 1, 0, 1,
            0, 0, 1, 0,
            0, 0, 0, 1
            );

        // Measurement matrix H (2x4)
        kf.measurementMatrix = cv::Mat::zeros(2, 4, CV_32F);
        kf.measurementMatrix.at<float>(0, 0) = 1.0f; // cx
        kf.measurementMatrix.at<float>(1, 1) = 1.0f; // cy

        // Process noise covariance Q
        kf.processNoiseCov = cv::Mat::eye(4, 4, CV_32F) * processNoise;

        // Measurement noise covariance R
        kf.measurementNoiseCov = cv::Mat::eye(2, 2, CV_32F) * measurementNoise;

        // Posterior error covariance
        kf.errorCovPost = cv::Mat::eye(4, 4, CV_32F);

        // initial state
        kf.statePost = cv::Mat::zeros(4, 1, CV_32F);
        kf.statePost.at<float>(0) = cx;
        kf.statePost.at<float>(1) = cy;
        kf.statePost.at<float>(2) = 0.0f;
        kf.statePost.at<float>(3) = 0.0f;
    }

    // 更新所有已有卡尔曼的噪声参数（热更新时调用）
    void updateAllKFNoise() {
        for (auto& t : tracks) {
            t.kf.processNoiseCov = cv::Mat::eye(4, 4, CV_32F) * processNoise;
            t.kf.measurementNoiseCov = cv::Mat::eye(2, 2, CV_32F) * measurementNoise;
        }
    }
};
