﻿#include "LicenseClient.h"
#include <iomanip>
#include <iostream>
#include <lmcons.h>
#include <sstream>
#include <string>
#include <wincrypt.h>
#include <windows.h>

#pragma comment(lib, "Advapi32.lib")

static std::string getHostName() {
	char buffer[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD size = sizeof(buffer);
	if (GetComputerNameA(buffer, &size)) {
		return std::string(buffer);
	}
	return "";
}

static std::string getUserNameStr() {
	char buffer[UNLEN + 1];
	DWORD size = sizeof(buffer);
	if (GetUserNameA(buffer, &size)) {
		return std::string(buffer);
	}
	return "";
}

static std::string getCpuName() {
	HKEY hKey;
	const char* subkey = "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0";
	if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, subkey, 0, KEY_READ, &hKey) != ERROR_SUCCESS)
		return "";

	char cpuName[256]{};
	DWORD size = sizeof(cpuName);
	DWORD type = 0;

	if (RegQueryValueExA(hKey, "ProcessorNameString", NULL, &type, (LPBYTE)cpuName, &size) == ERROR_SUCCESS) {
		RegCloseKey(hKey);
		return std::string(cpuName);
	}

	RegCloseKey(hKey);
	return "";
}

// 计算 SHA256
static std::string sha256(const std::string& input) {
	HCRYPTPROV hProv = 0;
	HCRYPTHASH hHash = 0;
	BYTE hash[32]; // SHA-256 输出 32 字节
	DWORD hashLen = sizeof(hash);

	std::ostringstream result;

	if (CryptAcquireContextA(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
		if (CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
			CryptHashData(hHash, reinterpret_cast<const BYTE*>(
				input.c_str()),
				static_cast<DWORD> (input.size()), 0
			);
			if (CryptGetHashParam(hHash, HP_HASHVAL, hash, &hashLen, 0)) {
				for (DWORD i = 0; i < hashLen; ++i)
					result << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
			}
			CryptDestroyHash(hHash);
		}
		CryptReleaseContext(hProv, 0);
	}
	return result.str();
}

static std::string getSHA() {
	try {
		std::string hostname = getHostName();
		std::string cpuinfo = getCpuName();
		std::string username = getUserNameStr();

		std::string combined = hostname + "-" + cpuinfo + "-" + username;
		return sha256(combined);
	}
	catch (const std::exception& e) {
		std::cerr << "get machine code failed: " << e.what() << std::endl;
		
		return "";
	}
}

void LicenseClient::setBaseURL(const std::string& baseURL) {
	std::lock_guard<std::mutex> lock(mtx);
	m_baseURL = baseURL;
}

void LicenseClient::setAppID(const std::string& appID) {
	std::lock_guard<std::mutex> lock(mtx);
	m_appID = appID;
}

std::string LicenseClient::getMachineCode() {
	return getSHA();
}

std::string LicenseClient::login(const std::string& cardKey, int timeout_ms) {
	std::string machineCode = getMachineCode();
	std::string fullUrl = m_baseURL + "/login";
	std::string postData = "&APP_ID=" + m_appID +
		"&CARD=" + cardKey +
		"&MACHINE_CODE=" + machineCode;
	return httpPost(fullUrl, postData, timeout_ms);
}

// ===============================
// 心跳函数
// ===============================
std::string LicenseClient::cert(const std::string& cardKey, int timeout_ms) {
	std::string machineCode = getMachineCode();
	std::string fullUrl = m_baseURL + "/cert";
	std::string postData = "APP_ID=" + m_appID +
		"&CARD=" + cardKey +
		"&MACHINE_CODE=" + machineCode;
	return httpPost(fullUrl, postData, timeout_ms);
}

// ===============================
// HTTP POST 实现
// ===============================
std::string LicenseClient::httpPost(const std::string& fullUrl, const std::string& data, int timeout_ms) {
	std::lock_guard<std::mutex> lock(mtx);

	HINTERNET hSession = nullptr, hConnect = nullptr, hRequest = nullptr;
	std::string response;
	DWORD dwSize = 0;
	BOOL bResults = FALSE;

	// 解析URL
	URL_COMPONENTS urlComp{};
	wchar_t hostName[256], urlPath[1024];
	urlComp.dwStructSize = sizeof(urlComp);
	urlComp.lpszHostName = hostName;
	urlComp.dwHostNameLength = _countof(hostName);
	urlComp.lpszUrlPath = urlPath;
	urlComp.dwUrlPathLength = _countof(urlPath);

	std::wstring wurl(fullUrl.begin(), fullUrl.end());
	if (!WinHttpCrackUrl(wurl.c_str(), 0, 0, &urlComp)) {
		return "Invalid URL";
	}

	// 创建 WinHTTP 会话
	hSession = WinHttpOpen(L"LicenseClient/1.0",
		WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
		WINHTTP_NO_PROXY_NAME,
		WINHTTP_NO_PROXY_BYPASS, 0);
	if (!hSession)
		return "Failed to initialize WinHTTP session";

	// 设置超时
	WinHttpSetTimeouts(hSession, timeout_ms, timeout_ms, timeout_ms, timeout_ms);

	// 连接主机
	hConnect = WinHttpConnect(hSession, urlComp.lpszHostName, urlComp.nPort, 0);
	if (!hConnect) {
		WinHttpCloseHandle(hSession);
		return "Connection failed";
	}

	DWORD flags = (urlComp.nPort == INTERNET_DEFAULT_HTTPS_PORT) ? WINHTTP_FLAG_SECURE : 0;

	// 创建请求
	hRequest = WinHttpOpenRequest(hConnect, L"POST", urlComp.lpszUrlPath,
		NULL, WINHTTP_NO_REFERER,
		WINHTTP_DEFAULT_ACCEPT_TYPES, flags);
	if (!hRequest) {
		WinHttpCloseHandle(hConnect);
		WinHttpCloseHandle(hSession);
		return "Failed to create HTTP request";
	}

	// 转换 POST 数据为宽字符串
	std::wstring wdata(data.begin(), data.end());

	// 发送请求
	bResults = WinHttpSendRequest(hRequest,
		L"Content-Type: application/x-www-form-urlencoded\r\n",
		-1L,
		(LPVOID)data.c_str(),
		(DWORD)(data.size() * sizeof(char)),
		(DWORD)(data.size() * sizeof(char)),
		0);

	if (!bResults) {
		response = "Failed to send HTTP request";
	}
	else {
		if (WinHttpReceiveResponse(hRequest, NULL)) {
			DWORD dwDownloaded = 0;
			do {
				WinHttpQueryDataAvailable(hRequest, &dwSize);
				if (!dwSize)
					break;

				std::string buffer(dwSize, 0);
				WinHttpReadData(hRequest, &buffer[0], dwSize, &dwDownloaded);
				response += buffer;
			} while (dwSize > 0);
		}
		else {
			response = "Failed to receive HTTP response";
		}
	}

	// 清理资源
	if (hRequest) WinHttpCloseHandle(hRequest);
	if (hConnect) WinHttpCloseHandle(hConnect);
	if (hSession) WinHttpCloseHandle(hSession);

	// 如果响应为空，则视为超时
	if (response.empty())
		return "Request timeout or empty response";

	return response;
}
