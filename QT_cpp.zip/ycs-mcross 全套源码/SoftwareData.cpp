﻿#include "SoftwareData.h"
#include "Config.h"
#include <filesystem>
#include "QBasic.h"
#include <YAML.h>

void SoftwareData::init()
{
	SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
	if (!std::filesystem::exists("data/config.yaml")) {
		genConfig();
	}

	yaml = YAML("data/config.yaml");
	yaml.parse();
	YAMLNode& root = yaml.getRoot();
	Config::instance().loadConfig(
		root["lastConfigFile"].getValue<std::string>()
	);

	// mkdirs
	CreateDirectoryA("configs", NULL);
}

YAMLNode& SoftwareData::getData()
{
	return yaml.getRoot();
}

void SoftwareData::write()
{
	yaml.writeToFile("data/config.yaml");
}

void SoftwareData::genConfig()
{
	YAML yaml;
	yaml.parse();
	YAMLNode& root = yaml.getRoot();
	root["lastConfigFile"].setRaw("\"configs/config.yaml\"");
	root["card"].setRaw("\"\"");
	root["autoSave"].setValue(true);
	yaml.writeToFile("data/config.yaml");
}

