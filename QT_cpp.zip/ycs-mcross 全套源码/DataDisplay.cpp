﻿#include <qpainter.h>
#include "DataDisplay.h"
#include "VideoGet.h"
#include "VisionPipeline.h"
#include "qtimer.h"
#pragma comment(lib, "opengl32.lib")

void MatViewerGL::setFrame(const cv::Mat& frame) {
	QMutexLocker locker(&mutex);
	frame.copyTo(currentFrame);
	update();
}

void MatViewerGL::initializeGL() {
	initializeOpenGLFunctions();
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

void MatViewerGL::paintGL() {
	glClear(GL_COLOR_BUFFER_BIT);
	cv::Mat frame;
	{
		QMutexLocker locker(&mutex);
		if (currentFrame.empty()) return;
		frame = currentFrame.clone();
	}

	glBindTexture(GL_TEXTURE_2D, textureID);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.cols, frame.rows, 0, GL_RGB, GL_UNSIGNED_BYTE, frame.data);

	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
	glTexCoord2f(0, 1); glVertex2f(-1, -1);
	glTexCoord2f(1, 1); glVertex2f(1, -1);
	glTexCoord2f(1, 0); glVertex2f(1, 1);
	glTexCoord2f(0, 0); glVertex2f(-1, 1);
	glEnd();
	glDisable(GL_TEXTURE_2D);
}

DataDisplay::DataDisplay(QWidget* parent)
	: QWidget(parent),
	timer_video(new QTimer(this)),
	timer_fps(new QTimer(this)),
	working(false),
	mtViewer(nullptr)
{
	ui.setupUi(this);

	mtViewer = new MatViewerGL(ui.videoDisplay);
	mtViewer->setGeometry(ui.videoDisplay->geometry());
	mtViewer->hide();
	ui.videoDisplay->setText("打开监视查看视频");

	connect(
		timer_video,
		&QTimer::timeout,
		this,
		&DataDisplay::updateVideoDisplay
	);
	connect(
		timer_fps,
		&QTimer::timeout,
		this,
		&DataDisplay::updateScreenShotFPS
	);
	connect(
		timer_fps,
		&QTimer::timeout,
		this,
		&DataDisplay::updateInferFPS
	);
	connect(
		timer_fps,
		&QTimer::timeout,
		this,
		&DataDisplay::updateModelInfo
	);

	displayMat = cv::Mat(
		ui.videoDisplay->height(),
		ui.videoDisplay->width(),
		CV_8UC3,
		cv::Scalar(0, 0, 0)
	);
	vw = ui.videoDisplay->width();
	vh = ui.videoDisplay->height();

	//startDisplay(); // debug
}

DataDisplay::~DataDisplay()
{
}

void DataDisplay::startDisplayVideo()
{
	// display video
	endDisplayVideo();
	mtViewer->show();
	working = true;
	frame_work = std::thread(&DataDisplay::frameWork, this);
	ui.videoDisplay->setText("");
	timer_video->start(33);
}

void DataDisplay::endDisplayVideo()
{
	// stop video display
	timer_video->stop();
	mtViewer->hide();
	ui.videoDisplay->setText("打开监视查看视频");
	working = false;
	if (frame_work.joinable()) {
		frame_work.join();
	}
}

void DataDisplay::startDisplayInfo()
{
	timer_fps->start(1000);
}

void DataDisplay::endDisplayInfo()
{
	timer_fps->stop();
	QListWidgetItem* item0 = ui.dataDisplayList->item(0);
	if (item0) {
		QString showText = QString("截图帧率：");
		item0->setText(showText);
	}

	QListWidgetItem* item1 = ui.dataDisplayList->item(1);
	if (item1) {
		QString showText = QString("推理帧率：");
		item1->setText(showText);
	}

	QListWidgetItem* item2 = ui.dataDisplayList->item(2);
	if (item2) {
		QString showText = QString("模型输入维度：");
		item2->setText(showText);
	}

	QListWidgetItem* item3 = ui.dataDisplayList->item(3);
	if (item3) {
		QString showText = QString("模型输出维度：");
		item3->setText(showText);
	}
}

void DataDisplay::updateVideoDisplay()
{
	mtViewer->setFrame(displayMat);
}

void DataDisplay::updateScreenShotFPS()
{
	double interval = VideoGet::instance().interval();
	int FPS = (interval > 0) ?
		static_cast<int>(1000.0 / interval) :
		0;

	QListWidgetItem* item0 = ui.dataDisplayList->item(0);
	if (item0) {
		QString showText = QString("截图帧率：%1 fps").arg(FPS);
		item0->setText(showText);
	}

}

void DataDisplay::updateInferFPS()
{
	double interval = VisionPipeline::interval();
	int FPS = (interval > 0) ?
		static_cast<int>(1000.0 / interval) :
		0;

	QListWidgetItem* item1 = ui.dataDisplayList->item(1);
	if (item1) {
		QString showText = QString("推理帧率：%1 fps").arg(FPS);
		item1->setText(showText);
	}
}

void DataDisplay::updateModelInfo()
{
	auto modelInfo = VisionPipeline::getModelInfo();
	int64_t input0 = modelInfo[0][0];
	int64_t input1 = modelInfo[0][1];
	int64_t input2 = modelInfo[0][2];
	int64_t input3 = modelInfo[0][3];

	int64_t output0 = modelInfo[1][0];
	int64_t output1 = modelInfo[1][1];
	int64_t output2 = modelInfo[1][2];

	QListWidgetItem* item2 = ui.dataDisplayList->item(2);
	if (item2) {
		QString showText = QString("模型输入维度：[%1, %2, %3, %4]")
			.arg(input0).arg(input1).arg(input2).arg(input3);
		item2->setText(showText);
	}

	QListWidgetItem* item3 = ui.dataDisplayList->item(3);
	if (item3) {
		QString showText = QString("模型输出维度：[%1, %2, %3]")
			.arg(output0).arg(output1).arg(output2);
		item3->setText(showText);
	}
}

void DataDisplay::frameWork()
{
	while (working) {
		cv::Mat frame_bgr = VideoGet::instance().get();
		cv::Mat frame_rgb;
		if (frame_bgr.empty()) return;

		cv::cvtColor(frame_bgr, frame_rgb, cv::COLOR_BGR2RGB);
		std::vector<Person> people = VisionPipeline::getCurrentPeople();

		bool printLine = false;
		Person aimPerson;
		for (const auto& p : people) {

			if (p.aiming) {
				printLine = true;
				aimPerson = p;
			}

			cv::rectangle(
				frame_rgb,
				cv::Rect(p.x, p.y, p.w, p.h),
				(p.aiming) ? cv::Scalar(0, 255, 0) : cv::Scalar(224, 224, 224),
				1
			);

			std::string id_text = std::to_string(p.id);

			cv::Point text_pos(p.x, p.y - 5);
			if (text_pos.y < 10) text_pos.y = p.y + 15;

			cv::putText(
				frame_rgb,
				id_text,
				text_pos,
				cv::FONT_HERSHEY_SIMPLEX,
				0.5,
				cv::Scalar(0, 0, 0),
				1,
				cv::LINE_AA
			);
		}

		if (printLine) {
			cv::line(
				frame_rgb,
				cv::Point(aimPerson.cx, aimPerson.cy),
				cv::Point(
					VideoGet::instance().getWidth() / 2,   // 注意别把宽高弄反
					VideoGet::instance().getHeight() / 2),
				cv::Scalar(0, 0, 255),  // 灰白色
				1,                          // 厚度为1像素
				cv::LINE_AA                 // 抗锯齿
			);
		}

		int fw = frame_rgb.cols;
		int fh = frame_rgb.rows;

		cv::Rect roiSrc, roiDst;

		if (fw <= vw && fh <= vh) {
			int x = (vw - fw) / 2;
			int y = (vh - fh) / 2;
			roiSrc = cv::Rect(0, 0, fw, fh);
			roiDst = cv::Rect(x, y, fw, fh);

			{
				std::lock_guard lock(mtx);
				frame_rgb(roiSrc).copyTo(displayMat(roiDst));
			}
		}
		else {
			int cropX = std::max(0, (fw - vw) / 2);
			int cropY = std::max(0, (fh - vh) / 2);
			int cropW = std::min(fw, vw);
			int cropH = std::min(fh, vh);
			roiSrc = cv::Rect(cropX, cropY, cropW, cropH);
			roiDst = cv::Rect(0, 0, cropW, cropH);

			{
				std::lock_guard lock(mtx);
				frame_rgb(roiSrc).copyTo(displayMat(roiDst));
			}
		}
	}
}

