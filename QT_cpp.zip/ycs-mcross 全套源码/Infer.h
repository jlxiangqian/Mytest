﻿#pragma once
#include <fstream>
#include <onnxruntime_cxx_api.h>
#include <opencv2/opencv.hpp>
#include <string>
#include <vector>


#ifdef _DEBUG
#pragma comment(lib, "opencv_world4110d.lib")
#else
#pragma comment(lib, "opencv_world4110.lib")
#endif // _DEBUG

typedef struct Person {
	float cx, cy, x, y, w, h, head_x, head_y, score;
	int id;
	bool aiming = false;
	Person(
		float cx, float cy,
		float x, float y,
		float w, float h,
		float head_x, float head_y,
		float score
	) :
		cx(cx), cy(cy), x(x), y(y), w(w), h(h),
		head_x(head_x), head_y(head_y), score(score), id(0)
	{
	}
	Person() :
		cx(0), cy(0), x(0), y(0), w(0), h(0),
		head_x(0), head_y(0), score(0), id(-1)
	{
	}
} Person;
std::ostream& operator<<(std::ostream& os, const Person& p);

struct Letterbox
{
	float pad_x, pad_y, scale;
};

class Infer
{
public:
	static Infer& instance(
		const std::string& model_path = "",
		const char* model_data = nullptr,
		size_t model_size = 0
	) {
		if (!ins) {
			ins = new Infer(model_path);
		}
		else {
			if (!ins->working_checkthread) {
				release();
				ins = new Infer(model_path);
			}
		}

		return *ins;
	}
	static void release() {
		if (ins) {
			delete ins;
			ins = nullptr;
		}
	}
	std::vector<Person> operator()(const cv::Mat& img);
	std::array<std::array<int64_t, 4>, 2> getModelInfo();

private:

	static Infer* ins;
	Infer(std::string model_path);
	~Infer();
	Infer(const Infer&) = delete;
	Infer& operator=(const Infer&) = delete;

	Ort::Env env;
	std::string model_path;
	Ort::Session session{ nullptr };
	Ort::AllocatorWithDefaultOptions allocator;

	Ort::MemoryInfo memory_info{ nullptr };
	Ort::Value input_tensor;
	Ort::Value output_tensor;

	std::array<int64_t, 4> input_shape{ 0, 0, 0, 0 };
	std::array<int64_t, 3> output_shape{ 0, 0, 0 };
	std::string input_name, output_name;

	std::vector<cv::Rect> boxes;
	std::vector<float> scores;
	std::vector<int> indices;

	cv::Mat blob;
	cv::Mat processed_img;
	Letterbox letterbox;

	std::atomic<bool> _available;
	std::atomic<bool> working_checkthread;

	std::thread check_thread;

	void preprocess(const cv::Mat& img, cv::Mat& dist, Letterbox& letterbox);
	void imgToTensor(const cv::Mat& img, Ort::Value& input_tensor);
	void inference(const Ort::Value& input_tensor, Ort::Value& output_tensor);

	std::vector<Person>postprocess(const Ort::Value& output_tensor, const Letterbox& letterbox);
	std::vector<Person> postprocess_v8(const Ort::Value& output_tensor, const Letterbox& letterbox);
	std::vector<Person> postprocess_v5(const Ort::Value& output_tensor, const Letterbox& letterbox);

	void check();


public:
	inline void PrintModelIOInfo()
	{
		auto OnnxTypeToString = [](ONNXTensorElementDataType type) -> const char* {
			switch (type) {
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT:   return "FLOAT";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT8:   return "UINT8";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT8:    return "INT8";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_UINT16:  return "UINT16";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT16:   return "INT16";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT32:   return "INT32";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64:   return "INT64";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_STRING:  return "STRING";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_BOOL:    return "BOOL";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16: return "FLOAT16";
			case ONNX_TENSOR_ELEMENT_DATA_TYPE_DOUBLE:  return "DOUBLE";
			default: return "UNKNOWN";
			}
			};

		size_t num_input_nodes = session.GetInputCount();
		size_t num_output_nodes = session.GetOutputCount();

		std::cout << "=== Model Inputs ===" << std::endl;
		for (size_t i = 0; i < num_input_nodes; ++i) {
			auto input_name = session.GetInputNameAllocated(i, allocator);
			Ort::TypeInfo type_info = session.GetInputTypeInfo(i);
			auto tensor_info = type_info.GetTensorTypeAndShapeInfo();
			auto shape = tensor_info.GetShape();
			auto type = tensor_info.GetElementType();

			std::cout << "Input [" << i << "] : " << input_name.get() << std::endl;
			std::cout << "  Shape: [";
			for (size_t j = 0; j < shape.size(); ++j) {
				std::cout << shape[j];
				if (j != shape.size() - 1) std::cout << ", ";
			}
			std::cout << "]" << std::endl;
			std::cout << "  Type : " << static_cast<int>(type) << " (" << OnnxTypeToString(type) << ")" << std::endl;
		}

		std::cout << "\n=== Model Outputs ===" << std::endl;
		for (size_t i = 0; i < num_output_nodes; ++i) {
			auto output_name = session.GetOutputNameAllocated(i, allocator);
			Ort::TypeInfo type_info = session.GetOutputTypeInfo(i);
			auto tensor_info = type_info.GetTensorTypeAndShapeInfo();
			auto shape = tensor_info.GetShape();
			auto type = tensor_info.GetElementType();

			std::cout << "Output [" << i << "] : " << output_name.get() << std::endl;
			std::cout << "  Shape: [";
			for (size_t j = 0; j < shape.size(); ++j) {
				std::cout << shape[j];
				if (j != shape.size() - 1) std::cout << ", ";
			}
			std::cout << "]" << std::endl;
			std::cout << "  Type : " << static_cast<int>(type) << " (" << OnnxTypeToString(type) << ")" << std::endl;
		}
	}
};

inline Infer* Infer::ins = nullptr;
