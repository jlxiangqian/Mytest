﻿#include <random>
#include "VideoGet.h"
#include "AimController.h"
#include "KalmanTracker.h"
#include "Config.h"
#include "KBM.h"

PIDController::PIDController(double kp, double ki, double kd)
	: kp(kp), ki(ki), kd(kd) {
}

void PIDController::setPID(double kp, double ki, double kd)
{
	this->kp = kp;
	this->ki = ki;
	this->kd = kd;
}

double PIDController::operator()(double error)
{
	if (fabs(error) < 1e-3)
		return 0.0;

	if (error * prevError < 0)
	{
		double current = fabs(error);
		double prev = fabs(prevError);
		if (current >= 0.8 * prev)
		{
			stabilityCounter++;
			if (stabilityCounter < stabilityThreshold)
			{
				integral *= 0.9;
				return prevError * kp * 0.1;
			}
			else
				stabilityCounter = 0;
		}
	}

	integral += error;
	integral = std::clamp(integral, -maxIntegral, maxIntegral);

	double derivative = error - prevError;
	derivative = 0.7 * derivative + 0.3 * prevDerivative;
	prevDerivative = derivative;
	prevError = error;

	double output = kp * error + ki * integral + kd * derivative;
	return output;
}

void PIDController::clear()
{
	prevError = 0.0;
	integral = 0.0;
	stabilityCounter = 0;
	prevDerivative = 0.0;
}

ByteTrack::ByteTrack() :
	iou_threshold(0.4f),
	score_threshold(0.3f),
	max_lost_time(10),
	reset_threshold(30),
	next_id(0),
	no_target_frames(0)
{
}

ByteTrack::ByteTrack(float iou_thres, float score_thres, int max_lost, int reset_thres)
	: iou_threshold(iou_thres),
	score_threshold(score_thres),
	max_lost_time(max_lost),
	reset_threshold(reset_thres),
	next_id(0),
	no_target_frames(0)
{
}

void ByteTrack::setIOUThreshold(float val) { iou_threshold = val; }

void ByteTrack::setScoreThreshold(float val) { score_threshold = val; }

void ByteTrack::setMaxLostTime(int val) { max_lost_time = val; }

void ByteTrack::setResetThreshold(int val) { reset_threshold = val; }

void ByteTrack::getPersonID(std::vector<Person>& people_without_id) {
	if (people_without_id.empty()) {
		no_target_frames++;
		if (no_target_frames >= reset_threshold) {
			clear();
		}
		return;
	}

	no_target_frames = 0; // reset counter

	std::vector<Person> detections;
	detections.reserve(people_without_id.size());
	for (auto& p : people_without_id) {
		if (p.score >= score_threshold)
			detections.push_back(p);
	}

	if (detections.empty()) return;

	std::vector<int> assigned_prev(prev_people.size(), 0);
	for (auto& det : detections) {
		int best_id = -1;
		float best_iou = 0.0f;
		for (size_t i = 0; i < prev_people.size(); ++i) {
			if (assigned_prev[i]) continue;
			float iou = calcIOU(det, prev_people[i]);
			if (iou > iou_threshold && iou > best_iou) {
				best_iou = iou;
				best_id = prev_people[i].id;
			}
		}

		if (best_id == -1)
			det.id = next_id++;
		else
			det.id = best_id;
	}

	people_without_id = detections;

	prev_people = detections;
}

void ByteTrack::clear() {
	prev_people.clear();
	next_id = 0;
	no_target_frames = 0;
}

float ByteTrack::calcIOU(const Person& a, const Person& b) {
	float x1 = std::max(a.x, b.x);
	float y1 = std::max(a.y, b.y);
	float x2 = std::min(a.x + a.w, b.x + b.w);
	float y2 = std::min(a.y + a.h, b.y + b.h);
	float interArea = std::max(0.0f, x2 - x1) * std::max(0.0f, y2 - y1);
	float unionArea = a.w * a.h + b.w * b.h - interArea;
	if (unionArea <= 0.0f) return 0.0f;
	return interArea / unionArea;
}

AimController::AimController() :
	no_people_times_count(0),
	aimID(-1),
	kalmanTracker(1e-3f, 5e-2f, 80.f, 20, 40),
	pidx(
		Config::instance().px,
		Config::instance().ix,
		Config::instance().dx
	),
	pidy(
		Config::instance().py,
		Config::instance().iy,
		Config::instance().dy
	)
{
	maxFps = Config::instance().max_fps;
	port = Config::instance().port;
	centerX = VideoGet::instance().getWidth() / 2;
	centerY = VideoGet::instance().getHeight() / 2;
}

AimController::~AimController()
{
	stop();
}

std::vector<Person> AimController::processMove(const std::vector<Person>& _people)
{
	// 如果aimID为非法值，那么取index。如果aimID为合法值，那么找aimID。如果没找到，那么维持上一次运动。
	std::vector<Person> people = _people;

	bool useLast = true;
	int index = -1;
	int current = -1;
	kalmanTracker.getPersonID(people);

	for (auto& p : people) {
		current++;
		if (p.id == aimID) {
			p.aiming = true;
			aimPerson = p;
			useLast = false;
			index = current;
			break;
		}
	}
	if (index == -1) {
		index = findClosestIndex(people);
	}

	if (index != -1) {
		people[index].aiming = true;
		aimPerson = people[index];
		aimID = aimPerson.id;
		useLast = false;
	}
	if (useLast && no_people_times_count > 0) { // 若计数器大于零且用过去的，则延续移动
		/*no_people_times_count--;
		{
			std::lock_guard lock(mtx);
			_move1.dx = _move1.dx * 0.5;
			_move1.dy = _move1.dy * 0.5;
			_move1.valid = true;

			_move2.dx = _move2.dx * 0.5;
			_move2.dy = _move2.dy * 0.5;
			_move2.valid = true;
		}*/

		{
			std::lock_guard lock(mtx);
			_move1.dx = 0;
			_move1.dy = 0;
			_move1.valid = false;

			_move2.dx = 0;
			_move2.dy = 0;
			_move2.valid = false;
		}
		aimID = 0;
		pidx.clear();
		pidy.clear();
		x_moves.clear();

	}
	else if (useLast && no_people_times_count <= 0) { // 若用过去的，但是计数器归零了
		{
			std::lock_guard lock(mtx);
			_move1.dx = 0;
			_move1.dy = 0;
			_move1.valid = false;

			_move2.dx = 0;
			_move2.dy = 0;
			_move2.valid = false;
		}
		aimID = 0;
		pidx.clear();
		pidy.clear();
		x_moves.clear();
	}
	else {										// 若不用过去的（当前人物有效）
		float useLead = isUseLead();
		{
			no_people_times_count = 5;
			std::lock_guard lock(mtx);
			_move1.dx = aimPerson.cx - centerX +
				useLead * Config::instance().lead * aimPerson.w;
			_move1.dy = aimPerson.head_y +
				aimPerson.h * Config::instance().offset1 -
				centerY;
			_move1.valid = true;

			_move2.dx = aimPerson.cx - centerX +
				useLead * Config::instance().lead * aimPerson.w;
			_move2.dy = aimPerson.head_y +
				aimPerson.h * Config::instance().offset2 -
				centerY;
			_move2.valid = true;
		}
	}

	return people;
}

int AimController::findClosestIndex(const std::vector<Person>& _people) const
{
	// calculate move
	int index = -1;
	int current = -1;
	float max_area = 0.f; // find biggest rectangle
	float min_dis = 10000.f;  // find the smallest distance

	struct erea_dis
	{
		float area = -1.f, dis = -1.f;
		erea_dis(float a, float d) : area(a), dis(d) {}
	};

	std::vector<erea_dis> area_dises;
	for (const auto& p : _people) {
		float width = p.w;
		float height = p.h;
		current++;

		float area = width * height;
		if (area > max_area) {
			max_area = area;
			index = current;
		}

		float dis =
			(p.cx - centerX) * (p.cx - centerX) +
			(p.cy - centerY) * (p.cy - centerY);
		if (dis < min_dis) {
			min_dis = dis;
			index = current;
		}

		area_dises.push_back({ area, dis });
	}

	float total_max = 0;
	current = -1;
	index = -1;
	for (auto& a_d : area_dises) {
		if (max_area <= 1e-6f) max_area = 1e-6f;
		if (a_d.dis <= 1e-6f) a_d.dis = 1e-6f;

		float area_score = a_d.area / max_area;
		float dis_score = min_dis / a_d.dis;
		float total = 0.333f * area_score + 0.667f * dis_score;
		current++;

		if (total > total_max) {
			total_max = total;
			index = current;
		}
	}

	return index;
}

void AimController::start()
{
	stop();

	maxFps = Config::instance().max_fps;
	int interval = static_cast<int> (1000.0 / maxFps);
	tH = timer.schedule_interval(
		std::chrono::milliseconds(interval),
		&AimController::oneMove, this
	);

	port = Config::instance().port;
	makcu.setSerial(port);

	working = true;
	check_thread = std::thread(&AimController::check, this);
}

void AimController::stop()
{
	timer.cancel(tH);
	working = false;
	if (check_thread.joinable()) {
		check_thread.join();
	}

	_move1.dx = 0;
	_move1.dy = 0;
	_move1.valid = false;

	_move2.dx = 0;
	_move2.dy = 0;
	_move2.valid = false;
}

void AimController::oneMove()
{
	int dx = 0, dy = 0;
	bool valid1 = false, valid2 = false;

	if (_GetKeyState(
		Config::instance().vkey2, Config::instance().dual_listen) ||
		Config::instance().vkey2 == 0) {
		std::lock_guard lock(mtx);
		dx = _move2.dx;
		dy = _move2.dy;
		valid2 = _move2.valid;
	}

	if (_GetKeyState(
		Config::instance().vkey1, Config::instance().dual_listen) ||
		Config::instance().vkey1 == 0
		) {
		std::lock_guard lock(mtx);
		dx = _move1.dx;
		dy = _move1.dy;
		valid1 = _move1.valid;
	}

	/*if (GetAsyncKeyState(
		Config::instance().vkey2) & 0x8000 ||
		Config::instance().vkey2 == 0) {
		std::lock_guard lock(mtx);
		dx = _move2.dx;
		dy = _move2.dy;
		valid2 = _move2.valid;
	}

	if (GetAsyncKeyState(
		Config::instance().vkey1) & 0x8000 ||
		Config::instance().vkey1 == 0
		) {
		std::lock_guard lock(mtx);
		dx = _move1.dx;
		dy = _move1.dy;
		valid1 = _move1.valid;
	}*/

	if (!valid1 && !valid2) {
		return;
	}

	double error_x = pidx(dx), error_y = pidy(dy);

	if (Config::instance().mouse_input == "B pro") {
		makcu.move(error_x, error_y);
	}
	else {
		winMouse.move(error_x, error_y);
	}

	shoot();

	push(error_x);

	{
		std::lock_guard lock(mtx);
		_move1.valid = false;
		_move2.valid = false;
	}
}

void AimController::shoot()
{
	using namespace std::chrono;
	if (!Config::instance().auto_fire) return;

	int x = aimPerson.x;
	int y = aimPerson.y;
	int w = aimPerson.w;
	int h = aimPerson.h;

	if (
		centerX < (x + w * 0.75) &&
		centerX >(x + w * 0.25) &&
		centerY < (y + h) &&
		centerY >(y)
		) {

		auto current = high_resolution_clock::now();
		auto diff = duration<double, std::milli>(current - time_point).count();
		if (diff >= 250.0) {
			time_point = high_resolution_clock::now();
			if (Config::instance().mouse_input == "B pro") {
				makcu.leftDown();
				makcu.leftUp();
			}
			else {
				winMouse.leftDown();
				winMouse.leftUp();
			}
		}
	}
}

void AimController::check()
{
	while (working) {
		if (port != Config::instance().port || !makcu.isConnect()) {
			port = Config::instance().port;
			makcu.setSerial(port);
		}

		if (maxFps != Config::instance().max_fps) {
			maxFps = Config::instance().max_fps;
			int interval = static_cast<int> (1000.0 / maxFps);
			tH.get()->interval = std::chrono::milliseconds(interval);
		}

		centerX = VideoGet::instance().getWidth() / 2;
		centerY = VideoGet::instance().getHeight() / 2;

		pidx.setPID(
			Config::instance().px,
			Config::instance().ix,
			Config::instance().dx
		);
		pidy.setPID(
			Config::instance().py,
			Config::instance().iy,
			Config::instance().dy
		);

		for (int i = 0; i < 10; ++i) {
			if (!working) break;
			std::this_thread::sleep_for(std::chrono::milliseconds(100));
		}
	}
}

box::MouseMakcu& AimController::getMakcu()
{
	return makcu;
}

WinMouse& AimController::getWinMouse()
{
	return winMouse;
}

void AimController::push(int dx)
{
	int threshold = 75; // use lead when same direction for 65ms.
	int interval = static_cast <int>(1000.0 / maxFps);

	int queLength = threshold / interval;
	if (queLength <= 28) queLength = 28;
	while (x_moves.size() >= queLength) x_moves.pop_front(); // delete front

	x_moves.push_back(dx);
}

int AimController::isUseLead()
{
	int threshold = 1;
	float persent = 0.8f;
	if (x_moves.size() <= 5) {
		return 0;
	}

	int count = 0;
	if (x_moves[0] < 0) {
		for (int dx : x_moves) {
			if (dx > -threshold) return 0;
			else count++;
		}

		if (count >= persent * x_moves.size()) return -1;
		else return 0;
	}
	else {
		for (int dx : x_moves) {
			if (dx < +threshold) return 0;
			else count++;
		}

		if (count >= persent * x_moves.size()) return 1;
		else return 0;
	}
}
