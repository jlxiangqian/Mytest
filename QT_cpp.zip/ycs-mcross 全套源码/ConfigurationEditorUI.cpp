﻿#include "ConfigurationEditorUI.h"
#include <qfiledialog.h>
#include "Config.h"
#include "HintOverlay.h"
#include "QBasic.h"
#include "KBM.h"

ConfigurationEditorUI::ConfigurationEditorUI(QWidget* parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	loadFromConfig();
	connect(
		this,
		&ConfigurationEditorUI::configChanged,
		this,
		&ConfigurationEditorUI::loadFromConfig
	);
	connect(
		ui.setVkeyButton1,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorUI::onVkeyButton1Pressed
	);
	connect(
		ui.setVkeyButton2,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorUI::onVkeyButton2Pressed
	);
	connect(
		ui.setDualListenButton,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorUI::onSetDualListenButtonPressed
	);
	connect(
		ui.setAutoFireButton,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorUI::onSetAutoFireButtonPressed
	);
	connect(
		ui.setOffsetSpinBox1,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onOffsetSpinBox1Changed
	);
	connect(
		ui.setOffsetSpinBox2,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onOffsetSpinBox2Changed
	);

	connect(
		ui.setPXSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onPXSpinBoxChanged
	);
	connect(
		ui.setIXSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onIXSpinBoxChanged
	);
	connect(
		ui.setDXSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onDXSpinBoxChanged
	);
	connect(
		ui.setPYSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onPYSpinBoxChanged
	);
	connect(
		ui.setIYSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onIYSpinBoxChanged
	);
	connect(
		ui.setDYSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onDYSpinBoxChanged
	);

	connect(
		ui.setLeadSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onLeadSpinBoxChanged
	);
	connect(
		ui.setModelPathButton,
		&QPushButton::pressed,
		this,
		&ConfigurationEditorUI::onModelPathButtonPressed
	);
	connect(
		ui.setModelId,
		&QSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onAimClassIdChanged
	);
	connect(
		ui.setConfSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onConfSpinBoxChanged
	);
	connect(
		ui.setIOUSpinBox,
		&QDoubleSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onIOUSpinBoxChanged
	);
	connect(
		ui.setModelInferMaxFPS,
		&QSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onModelInferMaxFPSChanged
	);
	connect(
		ui.setMouseInputComboBox,
		&QComboBox::currentTextChanged,
		this,
		&ConfigurationEditorUI::onMouseInputComboBoxChanged
	);
	connect(
		ui.setSerialSpinBox,
		&QSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onSerialSpinBoxChanged
	);
	connect(
		ui.setUrlLineEdit,
		&QLineEdit::textChanged,
		this,
		&ConfigurationEditorUI::onUrlLineEditChanged
	);
	connect(
		ui.setFovSpinBox,
		&QSpinBox::valueChanged,
		this,
		&ConfigurationEditorUI::onFovSpinBoxChanged
	);
}

ConfigurationEditorUI::~ConfigurationEditorUI()
{
}

void ConfigurationEditorUI::loadFromConfig()
{
	QString showText = "";

	if (inRange(Config::instance().vkey1, 0, 255)) {
		showText = QString("按键1 = %1").arg(Config::instance().vkey1);
		ui.showVkey1->setText(showText);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showVkey1->setText(showText);
	}

	if (inRange(Config::instance().offset1, -1.f, 1.f)) {
		showText = QString("Y轴偏移1 = %1").arg(Config::instance().offset1);
		ui.showOffset1->setText(showText);
		ui.setOffsetSpinBox1->setValue(Config::instance().offset1);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showOffset1->setText(showText);
	}

	if (inRange(Config::instance().vkey2, 0, 255)) {
		showText = QString("按键2 = %1").arg(Config::instance().vkey2);
		ui.showVkey2->setText(showText);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showVkey2->setText(showText);
	}

	if (inRange(Config::instance().offset2, -1.f, 1.f)) {
		showText = QString("Y轴偏移2 = %1").arg(Config::instance().offset2);
		ui.showOffset2->setText(showText);
		ui.setOffsetSpinBox2->setValue(Config::instance().offset2);

	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showOffset2->setText(showText);
	}

	showText = QString("双机按键监听 = %1").arg(
		Config::instance().dual_listen ?
		"true" : "false"
	);
	ui.showDualListen->setText(showText);

	showText = QString("自动开火 = %1").arg(
		Config::instance().auto_fire ?
		"true" : "false"
	);
	ui.showAutoFire->setText(showText);

	// pid x
	if (inRange(Config::instance().px, 0.f, 3.f)) {
		showText = QString("PX = %1").arg(Config::instance().px);
		ui.showPX->setText(showText);
		ui.setPXSpinBox->setValue(Config::instance().px);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showPX->setText(showText);
	}

	if (inRange(Config::instance().ix, 0.f, 3.f)) {
		showText = QString("IX = %1").arg(Config::instance().ix);
		ui.showIX->setText(showText);
		ui.setIXSpinBox->setValue(Config::instance().ix);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showIX->setText(showText);
	}

	if (inRange(Config::instance().dx, 0.f, 3.f)) {
		showText = QString("DX = %1").arg(Config::instance().dx);
		ui.showDX->setText(showText);
		ui.setDXSpinBox->setValue(Config::instance().dx);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showDX->setText(showText);
	}

	// pid y
	if (inRange(Config::instance().py, 0.f, 3.f)) {
		showText = QString("PY = %1").arg(Config::instance().py);
		ui.showPY->setText(showText);
		ui.setPYSpinBox->setValue(Config::instance().py);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showPY->setText(showText);
	}

	if (inRange(Config::instance().iy, 0.f, 3.f)) {
		showText = QString("IY = %1").arg(Config::instance().iy);
		ui.showIY->setText(showText);
		ui.setIYSpinBox->setValue(Config::instance().iy);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showIY->setText(showText);
	}

	if (inRange(Config::instance().dy, 0.f, 3.f)) {
		showText = QString("DY = %1").arg(Config::instance().dy);
		ui.showDY->setText(showText);
		ui.setDYSpinBox->setValue(Config::instance().dy);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showDY->setText(showText);
	}


	if (inRange(Config::instance().lead, 0.f, 20.f)) {
		showText = QString("提前量 = %1").arg(Config::instance().lead);
		ui.showLead->setText(showText);
		ui.setLeadSpinBox->setValue(Config::instance().lead);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showLead->setText(showText);
	}

	showText = QString("模型路径 = %1").arg(
		Config::instance().model_path.length() == 0 ?
		"null" : shortFilePath(fromWinString(Config::instance().model_path.c_str()))
	);
	ui.showModelPath->setText(showText);

	if (inRange(Config::instance().class_id, 0, 80)) {
		showText = QString("瞄准类ID = %1").arg(Config::instance().class_id);
		ui.showClassId->setText(showText);
		ui.setModelId->setValue(Config::instance().class_id);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showClassId->setText(showText);
	}

	if (inRange(Config::instance().conf_threshold, 0.f, 1.f)) {
		showText = QString("置信度阈值 = %1").arg(Config::instance().conf_threshold);
		ui.showConfThreshold->setText(showText);
		ui.setConfSpinBox->setValue(Config::instance().conf_threshold);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showConfThreshold->setText(showText);
	}

	if (inRange(Config::instance().conf_threshold, 0.f, 1.f)) {
		showText = QString("重合度阈值 = %1").arg(Config::instance().iou_threshold);
		ui.showIOUTreshold->setText(showText);
		ui.setIOUSpinBox->setValue(Config::instance().iou_threshold);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showIOUTreshold->setText(showText);
	}

	if (inRange(Config::instance().max_fps, 50, 1000)) {
		showText = QString("最大推理帧率 = %1").arg(Config::instance().max_fps);
		ui.showModelInferMaxFPS->setText(showText);
		ui.setModelInferMaxFPS->setValue(Config::instance().max_fps);
	}
	else {
		showText = QString("超出范围，请使用原生编辑");
		ui.showModelInferMaxFPS->setText(showText);
	}

	int index = ui.setMouseInputComboBox->findText(Config::instance().mouse_input.c_str());
	if (index >= 0) {
		showText = QString("鼠标输入 = %1").arg(
			Config::instance().mouse_input.length() == 0 ?
			"WinAPI" : Config::instance().mouse_input
		);
		ui.showMouseInput->setText(showText);
		ui.setMouseInputComboBox->setCurrentIndex(
			index >= 0 ? index : 0
		);
	}
	else {
		showText = QString("方式不存在，请使用原生编辑");
		ui.showMouseInput->setText(showText);
	}

	showText = QString("端口号 = %1").arg(
		Config::instance().port.length() == 0 ?
		"COM0" : Config::instance().port
	);
	ui.showSerial->setText(showText);
	if (!(Config::instance().port.length() < 4)) {
		const char* serial_num_str = Config::instance().port.c_str() + 3;
		int serial_num_int = std::stoi(serial_num_str);
		ui.setSerialSpinBox->setValue(serial_num_int);
	}
	else {
		ui.setSerialSpinBox->setValue(0);
	}

	showText = QString("视频流 = %1").arg(
		Config::instance().url.length() == 0 ? "udp://" : Config::instance().url
	);
	ui.showURL->setText(showText);
	if (!(Config::instance().url.length() < 7)) {
		const char* url_without_prefix = Config::instance().url.c_str() + 6;
		ui.setUrlLineEdit->setText(url_without_prefix);
	}
	else {
		ui.setUrlLineEdit->setText("");
	}

	if (Config::instance().width != Config::instance().height) {
		showText = QString("识别区域长宽不一致，请使用原生编辑");
	}
	else {
		showText = QString("范围 = %1").arg(Config::instance().width);
		ui.setFovSpinBox->setValue(Config::instance().width);
	}
	ui.showFov->setText(showText);
}

void ConfigurationEditorUI::onVkeyButton1Pressed()
{
	HintOverlay* hintOverlay = new HintOverlay(this);

	// find root
	QWidget* p = findRoot(this);

	QPoint topLeftGlobal = p->mapToGlobal(QPoint(0, 0));
	hintOverlay->setGeometry({ topLeftGlobal.x() + 200, topLeftGlobal.y() + 150, 400, 340 });
	hintOverlay->setHint("按下需要设置的按键");
	hintOverlay->setHintSize(12);
	int pressed_vkey = 0;
	std::thread t([&pressed_vkey] {
		KeyboardMonitor kbm;
		kbm.startMonitor();
		Sleep(1000);
		while (true) {
			int _pressed_vkey = 0;
			for (int i = 0; i < 256; i++) {
				if (kbm[i]) {
					_pressed_vkey = i;
					break;
				}
			}
			if (_pressed_vkey > 0) {
				pressed_vkey = _pressed_vkey;
				qDebug() << "vkey" << pressed_vkey;
				break;
			}
		}
		});
	t.detach();
	hintOverlay->setCloseCondition([&pressed_vkey] { return pressed_vkey > 0; });
	hintOverlay->exec();

	delete hintOverlay;
	hintOverlay = nullptr;

	Config::instance().vkey1 = pressed_vkey;
	QString showText = QString("按键1 = %1").arg(pressed_vkey);
	ui.showVkey1->setText(showText);
}

void ConfigurationEditorUI::onVkeyButton2Pressed()
{
	HintOverlay* hintOverlay = new HintOverlay(this);

	// find root
	QWidget* p = findRoot(this);

	QPoint topLeftGlobal = p->mapToGlobal(QPoint(0, 0));
	hintOverlay->setGeometry({ topLeftGlobal.x() + 200, topLeftGlobal.y() + 150, 400, 340 });
	hintOverlay->setHint("按下需要设置的按键");
	hintOverlay->setHintSize(12);
	int pressed_vkey = 0;
	std::thread t([&pressed_vkey] {
		KeyboardMonitor kbm;
		kbm.startMonitor();
		Sleep(1000);
		while (true) {
			int _pressed_vkey = 0;
			for (int i = 0; i < 256; i++) {
				if (kbm[i]) {
					_pressed_vkey = i;
					break;
				}
			}
			if (_pressed_vkey > 0) {
				pressed_vkey = _pressed_vkey;
				qDebug() << "vkey" << pressed_vkey;
				break;
			}
		}
		});
	t.detach();
	hintOverlay->setCloseCondition([&pressed_vkey] { return pressed_vkey > 0; });
	hintOverlay->exec();

	delete hintOverlay;
	hintOverlay = nullptr;

	Config::instance().vkey2 = pressed_vkey;
	QString showText = QString("按键2 = %1").arg(pressed_vkey);
	ui.showVkey2->setText(showText);
}

void ConfigurationEditorUI::onSetDualListenButtonPressed()
{
	Config::instance().dual_listen = !Config::instance().dual_listen;
	QString showText = QString("双机按键监听 = %1").arg(
		Config::instance().dual_listen ?
		"true" : "false"
	);
	ui.showDualListen->setText(showText);
}

void ConfigurationEditorUI::onSetAutoFireButtonPressed()
{
	Config::instance().auto_fire = !Config::instance().auto_fire;
	QString showText = QString("自动开火 = %1").arg(
		Config::instance().auto_fire ?
		"true" : "false"
	);
	ui.showAutoFire->setText(showText);
}

void ConfigurationEditorUI::onOffsetSpinBox1Changed(double value)
{
	Config::instance().offset1 = value;
	QString showText = QString("Y轴偏移1 = %1").arg(value);
	ui.showOffset1->setText(showText);
}

void ConfigurationEditorUI::onOffsetSpinBox2Changed(double value)
{
	Config::instance().offset2 = value;
	QString showText = QString("Y轴偏移2 = %1").arg(value);
	ui.showOffset2->setText(showText);
}

void ConfigurationEditorUI::onPXSpinBoxChanged(double value)
{
	Config::instance().px = value;
	QString showText = QString("PX = %1").arg(value);
	ui.showPX->setText(showText);
}

void ConfigurationEditorUI::onIXSpinBoxChanged(double value)
{
	Config::instance().ix = value;
	QString showText = QString("IX = %1").arg(value);
	ui.showIX->setText(showText);
}

void ConfigurationEditorUI::onDXSpinBoxChanged(double value)
{
	Config::instance().dx = value;
	QString showText = QString("DX = %1").arg(value);
	ui.showDX->setText(showText);
}

void ConfigurationEditorUI::onPYSpinBoxChanged(double value)
{
	Config::instance().py = value;
	QString showText = QString("PY = %1").arg(value);
	ui.showPY->setText(showText);
}

void ConfigurationEditorUI::onIYSpinBoxChanged(double value)
{
	Config::instance().iy = value;
	QString showText = QString("IY = %1").arg(value);
	ui.showIY->setText(showText);
}

void ConfigurationEditorUI::onDYSpinBoxChanged(double value)
{
	Config::instance().dy = value;
	QString showText = QString("DY = %1").arg(value);
	ui.showDY->setText(showText);
}

void ConfigurationEditorUI::onLeadSpinBoxChanged(double value)
{
	Config::instance().lead = value;
	QString showText = QString("提前量 = %1").arg(value);
	ui.showLead->setText(showText);
}

void ConfigurationEditorUI::onModelPathButtonPressed()
{
	QString fileName = QFileDialog::getOpenFileName(
		this,
		"选择模型",
		"",
		"模型文件 (*.onnx)"
	);

	if (!fileName.isEmpty()) {
		Config::instance().model_path = toWinString(fileName);
		QString showText = QString("模型路径 = %1").arg(shortFilePath(fileName));
		ui.showModelPath->setText(showText);
		qDebug() << "choosed model file:" << fileName;
	}
}

void ConfigurationEditorUI::onAimClassIdChanged(int value)
{
	Config::instance().class_id = value;
	QString showText = QString("瞄准类ID = %1").arg(value);
	ui.showClassId->setText(showText);
}

void ConfigurationEditorUI::onConfSpinBoxChanged(double value)
{
	Config::instance().conf_threshold = value;
	QString showText = QString("置信度阈值 = %1").arg(value);
	ui.showConfThreshold->setText(showText);
}

void ConfigurationEditorUI::onIOUSpinBoxChanged(double value)
{
	Config::instance().iou_threshold = value;
	QString showText = QString("重合度阈值 = %1").arg(value);
	ui.showIOUTreshold->setText(showText);
}

void ConfigurationEditorUI::onModelInferMaxFPSChanged(int value)
{
	Config::instance().max_fps = value;
	QString showText = QString("最大推理帧率 = %1").arg(value);
	ui.showModelInferMaxFPS->setText(showText);
}

void ConfigurationEditorUI::onMouseInputComboBoxChanged(const QString& value)
{
	Config::instance().mouse_input = value.toUtf8().constData();
	QString showText = QString("鼠标输入 = %1").arg(value);
	ui.showMouseInput->setText(showText);
}

void ConfigurationEditorUI::onSerialSpinBoxChanged(int value)
{
	QString port = QString("COM%1").arg(value);
	Config::instance().port = port.toUtf8().constData();
	QString showText = QString("端口号 = %1").arg(port);
	ui.showSerial->setText(showText);
}

void ConfigurationEditorUI::onUrlLineEditChanged(const QString& value)
{
	std::string prefix_std = "udp://";
	Config::instance().url = prefix_std + value.toUtf8().constData();
	QString showText = QString("视频流 = udp://%1").arg(value);
	ui.showURL->setText(showText);
}

void ConfigurationEditorUI::onFovSpinBoxChanged(int value)
{
	Config::instance().width = value;
	Config::instance().height = value;
	QString showText = QString("范围 = %1").arg(value);
	ui.showFov->setText(showText);
}
