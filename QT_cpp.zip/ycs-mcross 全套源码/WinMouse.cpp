﻿#include "WinMouse.h"
#include <Windows.h>

WinMouse::WinMouse()
{
}

void WinMouse::move(double x, double y)
{
	INPUT input = { 0 };
	input.type = INPUT_MOUSE;
	input.mi.dx = static_cast<int> (x);
	input.mi.dy = static_cast<int> (y);
	input.mi.dwFlags = MOUSEEVENTF_MOVE;
	SendInput(1, &input, sizeof(INPUT));
}

void WinMouse::leftDown()
{
	INPUT input = { 0 };
	input.type = INPUT_MOUSE;
	input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
	SendInput(1, &input, sizeof(INPUT));
}

void WinMouse::leftUp()
{
	INPUT input = { 0 };
	input.type = INPUT_MOUSE;
	input.mi.dwFlags = MOUSEEVENTF_LEFTUP;
	SendInput(1, &input, sizeof(INPUT));

}

void WinMouse::pressAndReleaseKeyboardKey(int vkey)
{
	INPUT inputs[2] = { 0 };

	inputs[0].type = INPUT_KEYBOARD;
	inputs[0].ki.wVk = vkey;

	inputs[1].type = INPUT_KEYBOARD;
	inputs[1].ki.wVk = vkey;
	inputs[1].ki.dwFlags = KEYEVENTF_KEYUP;

	SendInput(2, inputs, sizeof(INPUT));
}
