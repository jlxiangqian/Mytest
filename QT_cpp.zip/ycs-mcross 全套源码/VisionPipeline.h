﻿#pragma once
#include <Infer.h>
#include <Timer.h>
#include <atomic>
#include <string>
#include <thread>

class VisionPipeline
{
public:
	static std::string error_msg;

	static void init();
	static void start();
	static void stop();
	static void fpsMonitorReset();
	static void destruct();
	static void oneProcess();
	static void check();
	static bool iferror();
	static std::string handle_error();

	// font end interface
	static cv::Mat getCurrentFrame();
	static std::vector<Person> getCurrentPeople();
	static std::array<std::array<int64_t, 4>, 2> getModelInfo();
	static double interval();

private:
	static std::thread checkThread;
	static std::atomic<bool> working;
	static cv::Mat current_frame;
	static std::vector<Person> people;
	static std::mutex mtx;
	static std::atomic<double> _interval;
	static Timer timer;
	static TaskHandle tH;

	static int maxFps;
	static int frameCount;
	static double totalTimeMs;
	static double lastReportTime;
	static int64_t lastTK;
};

inline std::string VisionPipeline::error_msg = "";
inline std::thread VisionPipeline::checkThread;
inline std::atomic<bool> VisionPipeline::working = false;
inline cv::Mat VisionPipeline::current_frame;
inline std::vector<Person> VisionPipeline::people;
inline std::mutex VisionPipeline::mtx;
inline std::atomic<double> VisionPipeline::_interval = 0;
inline Timer VisionPipeline::timer;
inline TaskHandle VisionPipeline::tH;

inline int VisionPipeline::maxFps = 200;
inline int VisionPipeline::frameCount = 0;
inline double VisionPipeline::totalTimeMs = 0.0;
inline double VisionPipeline::lastReportTime = 0.0;
inline int64_t VisionPipeline::lastTK;
