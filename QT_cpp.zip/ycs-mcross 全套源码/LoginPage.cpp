﻿#include "LoginPage.h"
#include "QBasic.h"
#include "qtimer.h"
#include <qmessagebox.h>
#include "SoftwareData.h"

LoginPage::LoginPage(QWidget* parent)
	: QWidget(parent), working(false), hasPressed(false)
{
	ui.setupUi(this);
	license.setAppID("YCS-MCROSS");
	license.setBaseURL("http://47.113.230.209:12123");

	std::string card;
	try {
		card = SoftwareData::instance()
			.getData()["card"].getValue<std::string>();
	}
	catch (const std::exception&) {
		card = "";
	}
	ui.cardEdit->setText(fromWinString(card));

	connect(
		ui.loginButton,
		&QPushButton::pressed,
		this,
		&LoginPage::onLoginButtonPressed
	);
	connect(
		ui.cardEdit,
		&QLineEdit::returnPressed,
		this,
		&LoginPage::onLoginButtonPressed
	);
	connect(
		ui.contactAuthButton,
		&QPushButton::pressed,
		this,
		&LoginPage::onShowAuthInfoPressed
	);

	if (ui.cardEdit->text().length() >= 16) {
		QTimer::singleShot(2000, [this] {
			if (!hasPressed) {
				ui.loginButton->pressed();
			}
			});
	}
}

LoginPage::~LoginPage()
{
	working = false;
	if (cert_thread.joinable()) {
		cert_thread.join();
	}
}

void LoginPage::work()
{
	int total_sleep_ms = 3 * 60 * 1000;
	int sleep_interval_ms = 100;
	while (working) {
		for (int i = 0; i < total_sleep_ms / sleep_interval_ms && working; i++) {
			std::this_thread::sleep_for(
				std::chrono::milliseconds(sleep_interval_ms)
			);
		}

		QString result = QString::fromUtf8(
			license.cert(
				card, 5000
			).c_str()
		);

		// decide
		if (toWinString(result) == "0x10000000") { // success
			// no behavour
			std::cout << "heart beat success" << std::endl;
		}
		else { // failed
			std::cout << toWinString(result) << std::endl;
			QMessageBox::critical(this, "错误", result);
			ExitProcess(0);
		}
	}
}

void LoginPage::onLoginButtonPressed()
{
	hasPressed = true;
	ui.loginButton->setDisabled(true);
	QTimer::singleShot(5000, this, [this]() {
		ui.loginButton->setEnabled(true);
		});

	// save card
	card = toWinString(ui.cardEdit->text());
	SoftwareData::instance()
		.getData()["card"].setValue(card);
	SoftwareData::instance().write();

	// login
	QString result = QString::fromUtf8(
		license.login(
			card, 5000
		).c_str()
	);

	std::this_thread::sleep_for(std::chrono::milliseconds(500));

	bool success = false;
	// decide
	if (toWinString(result) == "0x10000000") { // success
		success = true;
		std::cout << "login success" << std::endl;
	}
	else if (toWinString(result) == "0x20000000") { // warning
		success = true;
		QMessageBox::warning(this, "警告", "机器码转绑超过10次将会锁定机器码");
	}
	else { // failed
		std::cout << toWinString(result) << std::endl;
		success = false;
		QMessageBox::critical(this, "错误", result);
	}

	if (success) {
		this->hide();
		hasPressed = true;
		working = true;
		cert_thread = std::thread(&LoginPage::work, this);
	}
}

void LoginPage::onShowAuthInfoPressed()
{
	hasPressed = true;
	QString text = R"(本软件为AI辅助瞄准框架，可以导入自定义模型，所有参数均支持热更新.
如有合作或源码购买需求，可联系作者.

该软件仅用于学习交流与技术展示，如有侵权请联系作者进行调整.


作者：CodeConfession.
联系方式：QQ3890982546.)";
	QMessageBox::about(this, "YCS-MCROSS", text);
}

