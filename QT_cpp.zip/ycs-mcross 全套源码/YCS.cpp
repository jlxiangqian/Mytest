﻿#include <qevent.h>
#include <qmessagebox.h>
#include <qtimer.h>
#include "SoftwareData.h"
#include "AimController.h"
#include "Config.h"
#include "LoginPage.h"
#include "VisionPipeline.h"
#include "YCS.h"
#include "makcu.h"

YCS::YCS(QWidget* parent)
	: QWidget(parent)
{
	ui.setupUi(this);

	configurationEditor = new ConfigurationEditor(ui.configurationEditorArea);
	dataDisplay = new DataDisplay(ui.dataDisplayArea);
	dataDisplay->startDisplayInfo();
	controlPanel = new ControlPanel(ui.controlPanelArea);
	new LoginPage(this);

	connect(
		controlPanel->getMonitorButton(),
		&QPushButton::pressed,
		this,
		&YCS::onControlPanelMonitorPressed
	);

	connect(
		controlPanel->getTestButton(),
		&QPushButton::pressed,
		this,
		&YCS::onControlPanelTestPressed
	);
}

YCS::~YCS()
{
	dataDisplay->endDisplayInfo();
}

void YCS::closeEvent(QCloseEvent* event)
{
	if (controlPanel->getStartButton()->isChecked()) {
		controlPanel->getStartButton()->pressed();
	}
	if (controlPanel->getTestButton()->isChecked()) {
		controlPanel->getTestButton()->pressed();
	}
	if (controlPanel->getMonitorButton()->isChecked()) {
		controlPanel->getMonitorButton()->pressed();
	}
	if (
		SoftwareData::instance()
		.getData()["autoSave"]
		.getValue<bool>()
		) {
		if (SoftwareData::instance()
			.getData()["lastConfigFile"]
			.getValue<std::string>() != "null") {
			Config::instance().writeConfig(
				SoftwareData::instance()
				.getData()["lastConfigFile"]
				.getValue<std::string>()
			);
		}
	}

	ExitProcess(0);
}

void YCS::onControlPanelMonitorPressed()
{
	bool monitored = controlPanel->getMonitorButton()->isChecked();
	if (!monitored) {
		dataDisplay->startDisplayVideo();
	}
	else {
		dataDisplay->endDisplayVideo();
	}
}

void YCS::onControlPanelTestPressed()
{
	AimController::instance()
		.getMakcu()
		.setSerial(
			Config::instance().port
		);

	if (Config::instance().mouse_input == "B pro" &&
		!AimController::instance().getMakcu().isConnect()
		) {
		QMessageBox::critical(
			this,
			"错误",
			"设备连接失败，修改端口号后重试"
		);
		return;
	}

	controlPanel->getTestButton()->setDisabled(true);
	QTimer::singleShot(
		std::chrono::milliseconds(3 * 1000),
		controlPanel->getTestButton(),
		[this] {
			controlPanel->getTestButton()->setEnabled(true);
			QMessageBox::information(
				this,
				"鼠标测试完毕",
				"鼠标动了吗？如果鼠标没有移动，请重新连接盒子或者重刷固件"
			);
		}
	);

	std::thread([] {
		if (Config::instance().mouse_input == "B pro") {
			for (int i = 0; i < 500; i++) {

				AimController::instance()
					.getMakcu().move(-1, -1);
			}
			Sleep(100);
			for (int i = 0; i < 500; i++) {
				AimController::instance()
					.getMakcu().move(1, 1);
			}
			Sleep(100);
			for (int i = 0; i < 500; i++) {
				AimController::instance()
					.getMakcu().move(-1, -1);
			}
			Sleep(100);
			for (int i = 0; i < 500; i++) {
				AimController::instance()
					.getMakcu().move(1, 1);
			}
		}
		else {
			for (int i = 0; i < 500; i++) {
				AimController::instance()
					.getWinMouse().move(-1, -1);
			}
			Sleep(100);
			for (int i = 0; i < 500; i++) {
				AimController::instance()
					.getWinMouse().move(1, 1);
			}
			Sleep(100);
			for (int i = 0; i < 500; i++) {
				AimController::instance()
					.getWinMouse().move(-1, -1);
			}
			Sleep(100);
			for (int i = 0; i < 500; i++) {
				AimController::instance()
					.getWinMouse().move(1, 1);
			}
		}

		}).detach();
}
