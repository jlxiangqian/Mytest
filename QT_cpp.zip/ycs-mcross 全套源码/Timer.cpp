#include <thread>
#include "Timer.h"

Timer::Timer() : stop_(false) {
	worker_ = std::thread(&Timer::run, this);
}

Timer::~Timer() {
	{
		std::unique_lock<std::mutex> lock(mtx_);
		stop_ = true;
	}
	cv_.notify_one();
	if (worker_.joinable()) {
		worker_.join();
	}
}

void Timer::cancel(TaskHandle handle) {
	if (handle) {
		std::unique_lock<std::mutex> lock(mtx_);
		handle->canceled = true;
	}
}

void Timer::addTask(TaskHandle task) {
	std::unique_lock<std::mutex> lock(mtx_);
	tasks_.push(task);
	cv_.notify_one();
}

void Timer::run() {
	std::unique_lock<std::mutex> lock(mtx_);
	while (true) {
		if (stop_ && tasks_.empty()) {
			break;
		}
		if (tasks_.empty()) {
			cv_.wait(lock);
			continue;
		}
		TaskHandle current = tasks_.top();
		auto now = std::chrono::steady_clock::now();

		if (now >= current->nextTime) {
			tasks_.pop();
			if (!current->canceled) {
				lock.unlock();
				current->func();
				lock.lock();
			}

			if (current->interval.count() > 0 && !current->canceled) {
				current->nextTime = current->nextTime + current->interval;
				tasks_.push(current);
			}
		}
		else {
			cv_.wait_until(lock, current->nextTime);
		}
	}
}
