﻿#pragma once
#include <QWidget>
#include <opencv2/opencv.hpp>
#include <thread>
#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <qmutex.h>
#include <opencv2/opencv.hpp>
#include "ui_DataDisplay.h"

class MatViewerGL : public QOpenGLWidget, protected QOpenGLFunctions {
    Q_OBJECT

public:
    MatViewerGL(QWidget* parent = nullptr) : QOpenGLWidget(parent) {}
    void setFrame(const cv::Mat& frame);

protected:
    void initializeGL() override;
    void paintGL() override;

private:
    GLuint textureID;
    cv::Mat currentFrame;
    QMutex mutex;
};


class DataDisplay : public QWidget
{
	Q_OBJECT

public:
	DataDisplay(QWidget *parent = nullptr);
	~DataDisplay();

	void startDisplayVideo();
	void endDisplayVideo();
	void startDisplayInfo();
	void endDisplayInfo();

private:
	Ui::DataDisplayClass ui;

	int vw, vh;
	std::thread frame_work;
	std::mutex mtx;
	std::atomic<bool> working;
	cv::Mat displayMat;
	QTimer* timer_video;
	QTimer* timer_fps;
	MatViewerGL* mtViewer;


private slots:
	void updateVideoDisplay();
	void updateScreenShotFPS();
	void updateInferFPS();
	void updateModelInfo();
	void frameWork();
};
