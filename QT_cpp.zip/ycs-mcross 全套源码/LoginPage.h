﻿#pragma once

#include <QWidget>
#include "ui_LoginPage.h"
#include "LicenseClient.h"

class LoginPage : public QWidget
{
	Q_OBJECT

public:
	LoginPage(QWidget* parent = nullptr);
	~LoginPage();

private:
	Ui::LoginPageClass ui;
	LicenseClient license;
	std::thread cert_thread;
	std::atomic<bool> working;
	std::atomic<bool> hasPressed;
	std::string card;


	void work(); // check

	void onLoginButtonPressed();
	void onShowAuthInfoPressed();
};

//QLineEdit#cardEdit{
//	border: 1px solid rgb(120, 120, 120);
//	border - radius: 4px;
//	padding: 4px;
//	background - color: rgb(248, 254, 255);
//}
//
//QLineEdit#cardEdit:focus{
//	border: 1px solid rgb(85, 170, 255);
//	border - radius: 4px;
//	padding: 4px;
//	background - color: rgb(255, 255, 255);
//}
