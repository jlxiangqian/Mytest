﻿#pragma once
#include <windows.h>
#include <winhttp.h>
#include <string>
#include <mutex>
#include <iostream>

#pragma comment(lib, "winhttp.lib")
class LicenseClient
{
public:
    void setBaseURL(const std::string& baseURL);   // 设置基础 URL（不带路径）
    void setAppID(const std::string& appID);       // 设置应用 ID

    std::string getMachineCode();                  // 获取机器码（留空定义，由用户实现）
    std::string login(const std::string& cardKey, int timeout_ms);  // 登录验证
    std::string cert(const std::string& cardKey, int timeout_ms);   // 心跳验证

private:
    std::mutex mtx;
    std::string m_baseURL;   // 例如：https://yourserver.com/api
    std::string m_appID;     // 应用标识

    // 通用 HTTP POST 方法
    std::string httpPost(const std::string& fullUrl, const std::string& data, int timeout_ms);
};

